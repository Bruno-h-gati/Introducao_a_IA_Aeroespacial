# -*- coding: utf-8 -*-
"""
AGENTE ENGENHEIRO - triagem preliminar de aeronaves usando BCA em PDF.

Arquivos na mesma pasta:
  - agente_engenheiro_gemini.py
  - BCA_2026.pdf

Dependências:
  pip install -U google-genai pydantic pypdf

Configuração no PowerShell:
  setx GEMINI_API_KEY "SUA_CHAVE_API"
  setx GEMINI_MODEL "gemma-4-31b-it"

Feche e reabra o terminal após usar setx.

Arquitetura:
  1. Identifica páginas potencialmente relacionadas às tabelas de jatos.
  2. Divide as páginas candidatas em lotes e extrai o BCA dinamicamente com Gemini.
  3. Salva o catálogo extraído em cache JSON para reutilização.
  4. Faz comparações objetivas em Python.
  5. Executa análises especializadas: alcance, capacidade, pista e consolidação.
  6. Controla chamadas de geração: intervalo mínimo de 30 s, no máximo 2/min
     e teto local conservador de 14.000 tokens/min.

Observação sobre limites:
- O controle de 30 segundos é aplicado às chamadas generate_content.
- count_tokens e upload/delete de arquivos são operações separadas da geração.
- A quota real depende do projeto, modelo e nível de faturamento no Google AI.
- O limite local de 14.000 tokens/min é uma proteção conservadora, não uma
  declaração da quota oficial da conta.
"""

from __future__ import annotations

import json
import hashlib
import httpx
import logging
import os
import random
import re
import sys
import tempfile
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Optional

from google import genai
from google.genai import types
from pydantic import BaseModel, Field, ValidationError
from pypdf import PdfReader, PdfWriter


# =============================================================================
# PADRÃO DE SAÍDA NO TERMINAL (bloco idêntico nos quatro agentes)
# Sem símbolos fora do cp1252, para não falhar em consoles Windows.
# =============================================================================

_LARGURA_LOG = 70


def log_banner(agente: str, descricao: str = "") -> None:
    print("=" * _LARGURA_LOG)
    print(f"{agente} | {descricao}" if descricao else agente)
    print("=" * _LARGURA_LOG, flush=True)


def log_etapa(atual: int, total: int, texto: str) -> None:
    print(f"\n[{atual}/{total}] {texto}", flush=True)


def log_sub(texto: str) -> None:
    print(f"\n> {texto}", flush=True)


def log_info(texto: str) -> None:
    print(f"  {texto}", flush=True)


def log_api(texto: str) -> None:
    print(f"  [API] {texto}", flush=True)


def log_cache(texto: str) -> None:
    print(f"  [CACHE] {texto}", flush=True)


def log_ok(texto: str) -> None:
    print(f"  [OK] {texto}", flush=True)


def log_aviso(texto: str) -> None:
    print(f"  [AVISO] {texto}", flush=True)


def log_erro(texto: str) -> None:
    print(f"\n[ERRO] {texto}", flush=True)


def log_resultado(itens: list[tuple[str, object]]) -> None:
    largura = max((len(str(k)) for k, _ in itens), default=0)
    print("\n" + "-" * _LARGURA_LOG)
    print("RESULTADO")
    for chave, valor in itens:
        print(f"  {str(chave).ljust(largura)} : {valor}")
    print("-" * _LARGURA_LOG, flush=True)


# =============================================================================
# 1. CONFIGURAÇÕES
# =============================================================================

BASE_DIR = Path(__file__).resolve().parent

# Localiza a raiz do projeto
if BASE_DIR.name == "Projeto_Final_Gemini":
    PASTA_PROJETO = BASE_DIR
else:
    PASTA_PROJETO = BASE_DIR.parent

# PDF de referência
PDF_BCA = BASE_DIR / "BCA_2026.pdf"

# Catálogo de aeronaves
PASTA_CACHE = PASTA_PROJETO / "02_mercado"

# Resultados do Engenheiro
PASTA_SAIDA = PASTA_PROJETO / "03_triagem"

# Caches das análises especializadas
PASTA_CACHE_ANALISES = PASTA_SAIDA / "cache_analises"

# Criação das pastas
PASTA_CACHE.mkdir(parents=True, exist_ok=True)
PASTA_SAIDA.mkdir(parents=True, exist_ok=True)
PASTA_CACHE_ANALISES.mkdir(parents=True, exist_ok=True)

API_KEY = os.getenv("GEMINI_API_KEY")
MODELO_GEMINI = os.getenv("GEMINI_MODEL", "gemma-4-31b-it")
#gemma-4-31b-it

TIMEOUT_MS = 1200_000
MAX_TENTATIVAS = 10

# Controle local de geração Gemini.
MIN_INTERVALO_CHAMADAS_SEGUNDOS = 30
MAX_CHAMADAS_POR_MINUTO = 1
LIMITE_TOKENS_POR_MINUTO = 14_000
JANELA_SEGUNDOS = 60
MARGEM_CONTAGEM_TOKENS = 1.10

# Quantas páginas candidatas vão em cada PDF temporário.
PAGINAS_POR_LOTE = 8

# "todas" = catálogo completo; "jatos" = apenas jatos executivos.
ESCOPO_AERONAVES = "todas"
VERSAO_EXTRACAO = "2026-10-31-gemma-json-prompt-v3"

# Consolidação final: quantidade inicial de aeronaves por grupo.
# O agente reduz automaticamente o grupo se a contagem de tokens ficar alta.
CANDIDATOS_POR_LOTE_CONSOLIDACAO = 64
TETO_TOKENS_CONSOLIDACAO = 7_000

# Modo rápido: só as aeronaves que passaram na triagem em Python vão ao modelo,
# e a análise vira UMA única chamada (em vez de 3 áreas x lotes + consolidação).
# Defina MODO_RAPIDO = False para voltar às análises por área (alcance/capacidade/pista),
# mas ainda enviando apenas os candidatos.
MODO_RAPIDO = True
MAX_CANDIDATOS_CHAMADA_UNICA = 15

# O catálogo completo já fica salvo em 02_mercado/*_aeronaves_extraidas.json.
# Repeti-lo em cada relatório só aumenta o arquivo.
INCLUIR_CATALOGO_COMPLETO_NO_RELATORIO = False

# Termos usados apenas para localizar páginas candidatas no texto do PDF.
# As páginas vizinhas também são incluídas para não cortar tabelas entre páginas.
TERMOS_BCA = (
    "nbaa ifr",
    "takeoff field length",
    "take-off field length",
    "tofl",
    "equipped price",
    "business jet",
    "business jets",
    "executive jet",
    "executive jets",
    "jet aircraft",
    "aircraft comparison",
)

if not API_KEY:
    raise EnvironmentError(
        "GEMINI_API_KEY não encontrada. Configure no PowerShell com "
        'setx GEMINI_API_KEY "SUA_CHAVE_API" e reabra o terminal.'
    )

client = genai.Client(
    api_key=API_KEY,
    http_options=types.HttpOptions(timeout=TIMEOUT_MS),
)


# =============================================================================
# 2. CONTROLE DE CHAMADAS E TOKENS
# =============================================================================

# Cada registro: (instante_monotônico, tokens_estimados).
HISTORICO_GEMINI: deque[tuple[float, int]] = deque()
ULTIMA_CHAMADA_GERACAO: Optional[float] = None
LOCK_GEMINI = Lock()


def _limpar_historico_agora(agora: float) -> None:
    while HISTORICO_GEMINI and agora - HISTORICO_GEMINI[0][0] >= JANELA_SEGUNDOS:
        HISTORICO_GEMINI.popleft()


def contar_tokens_entrada(conteudos) -> int:
    """Conta os tokens de entrada antes de cada tentativa de geração."""
    resposta = client.models.count_tokens(
        model=MODELO_GEMINI,
        contents=conteudos,
    )
    total = getattr(resposta, "total_tokens", None)
    if total is None:
        raise RuntimeError("A API não retornou total_tokens na contagem.")
    estimado = int(total * MARGEM_CONTAGEM_TOKENS)
    log_api(f"Tokens de entrada: {total:,}")
    if estimado > LIMITE_TOKENS_POR_MINUTO:
        raise RuntimeError(
            f"Esta solicitação exige aproximadamente {estimado:,} tokens, "
            f"acima do limite local de {LIMITE_TOKENS_POR_MINUTO:,}. "
            "Reduza o lote de páginas ou divida a análise."
        )
    return estimado


def aguardar_e_registrar_chamada(tokens_estimados: int) -> None:
    """
    Aplica intervalo mínimo, limite de chamadas/minuto e limite de tokens/minuto.
    A reserva é registrada antes da chamada, inclusive se a geração falhar.
    """
    global ULTIMA_CHAMADA_GERACAO

    while True:
        with LOCK_GEMINI:
            agora = time.monotonic()
            _limpar_historico_agora(agora)

            esperas = []

            if ULTIMA_CHAMADA_GERACAO is not None:
                decorrido = agora - ULTIMA_CHAMADA_GERACAO
                if decorrido < MIN_INTERVALO_CHAMADAS_SEGUNDOS:
                    esperas.append(MIN_INTERVALO_CHAMADAS_SEGUNDOS - decorrido)

            if len(HISTORICO_GEMINI) >= MAX_CHAMADAS_POR_MINUTO:
                tempo_liberacao = (
                    HISTORICO_GEMINI[0][0] + JANELA_SEGUNDOS - agora
                )
                if tempo_liberacao > 0:
                    esperas.append(tempo_liberacao)

            tokens_janela = sum(item[1] for item in HISTORICO_GEMINI)
            if tokens_janela + tokens_estimados > LIMITE_TOKENS_POR_MINUTO:
                if HISTORICO_GEMINI:
                    tempo_liberacao = (
                        HISTORICO_GEMINI[0][0] + JANELA_SEGUNDOS - agora
                    )
                    if tempo_liberacao > 0:
                        esperas.append(tempo_liberacao)
                else:
                    raise RuntimeError(
                        "A solicitação excede sozinha o limite local de tokens/minuto."
                    )

            espera = max(esperas, default=0.0)
            if espera <= 0:
                instante = time.monotonic()
                HISTORICO_GEMINI.append((instante, tokens_estimados))
                ULTIMA_CHAMADA_GERACAO = instante
                return

        log_api(f"Aguardando quota: {espera:.1f}s")
        time.sleep(espera + 0.2)


def extrair_tempo_retry(erro: Exception) -> Optional[float]:
    """Tenta obter retryDelay informado pela API do Google."""
    texto = str(erro)
    padroes = [
        r"retry in ([0-9.]+)s",
        r"retryDelay['\"]?\s*:\s*['\"]([0-9.]+)s",
        r"retry_delay['\"]?\s*:\s*['\"]?([0-9.]+)",
    ]
    for padrao in padroes:
        achado = re.search(padrao, texto, flags=re.I)
        if achado:
            try:
                return float(achado.group(1))
            except ValueError:
                pass
    return None


def erro_temporario(erro: Exception) -> bool:
    if isinstance(erro, (httpx.TimeoutException, httpx.TransportError)):
        return True
    texto = str(erro).lower()
    marcadores = (
        "429", "503", "504", "500", "502", "resource_exhausted",
        "unavailable", "deadline", "timeout", "temporarily",
        "internal server error", "rate limit", "quota",
    )
    return any(m in texto for m in marcadores)


def _extrair_json(texto: str):
    """Localiza um objeto JSON completo, sem alterar valores da resposta."""
    texto = texto.strip()
    texto = re.sub(r"^```(?:json)?\s*", "", texto, flags=re.I)
    texto = re.sub(r"\s*```$", "", texto)
    decoder = json.JSONDecoder()
    try:
        return json.loads(texto)
    except json.JSONDecodeError:
        pass
    for pos, char in enumerate(texto):
        if char != "{":
            continue
        try:
            objeto, _ = decoder.raw_decode(texto[pos:])
            if isinstance(objeto, dict):
                return objeto
        except json.JSONDecodeError:
            continue
    raise ValueError("A resposta não contém objeto JSON completo e válido.")


def _validar_resposta_gemma(resposta, schema):
    texto = (getattr(resposta, "text", None) or "").strip()
    if not texto:
        motivo = getattr(resposta, "prompt_feedback", None)
        candidatos = getattr(resposta, "candidates", None)
        raise ValueError(f"Resposta vazia do modelo. feedback={motivo}; candidates={candidatos}")
    return schema.model_validate(_extrair_json(texto))


def gerar_com_controle(
    conteudos,
    *,
    response_schema,
    descricao: str,
):
    """Chama Gemma sem response_schema e valida o JSON localmente."""
    ultimo_erro = None
    instrucao = (
        "Responda EXCLUSIVAMENTE com um único objeto JSON válido, sem markdown, "
        "sem texto antes/depois e sem comentários. Use exatamente estas chaves "
        "e tipos de dados definidos no esquema JSON a seguir. "
        "Para campos opcionais sem evidência, use null; para listas use []. "
        "Não invente informações.\nESQUEMA JSON:\n"
        + json.dumps(response_schema.model_json_schema(), ensure_ascii=False)
    )
    conteudos_atuais = list(conteudos) + [instrucao]

    # Cada chamada especializada/consolidação tem seu próprio JSON persistente.
    # A chave depende do modelo, do prompt completo e do schema: mudanças
    # nos requisitos, aeronaves ou instruções invalidam o cache automaticamente.
    usar_cache = not descricao.startswith("extração BCA")
    arquivo_cache = None
    if usar_cache:
        PASTA_CACHE_ANALISES.mkdir(parents=True, exist_ok=True)
        identificador = re.sub(r"[^a-zA-Z0-9_-]+", "_", descricao).strip("_")[:65]
        material = json.dumps({
            "modelo": MODELO_GEMINI,
            "conteudos": [str(c) for c in conteudos_atuais],
            "schema": response_schema.model_json_schema(),
            "temperature": 0.1,
        }, ensure_ascii=False, sort_keys=True)
        assinatura = hashlib.sha256(material.encode("utf-8")).hexdigest()[:20]
        arquivo_cache = PASTA_CACHE_ANALISES / f"{identificador}_{assinatura}.json"
        if arquivo_cache.is_file():
            try:
                salvo = json.loads(arquivo_cache.read_text(encoding="utf-8"))
                resultado = response_schema.model_validate(salvo["resultado"])
                log_cache(f"{descricao}: recuperado")
                return resultado
            except (ValueError, KeyError, TypeError) as exc:
                log_aviso(f"Cache inválido ({exc}); refazendo")

    for tentativa in range(1, MAX_TENTATIVAS + 1):
        log_api(f"{descricao} - tentativa {tentativa}/{MAX_TENTATIVAS}")
        tokens = contar_tokens_entrada(conteudos_atuais)
        aguardar_e_registrar_chamada(tokens)
        try:
            resposta = client.models.generate_content(
                model=MODELO_GEMINI,
                contents=conteudos_atuais,
                config=types.GenerateContentConfig(temperature=0.1),
            )
            resultado = _validar_resposta_gemma(resposta, response_schema)
            if arquivo_cache is not None:
                registro = {
                    "descricao": descricao,
                    "modelo": MODELO_GEMINI,
                    "criado_em": datetime.now().astimezone().isoformat(),
                    "assinatura_entrada": assinatura,
                    "resultado": resultado.model_dump(mode="json"),
                }
                # Escrita atômica evita JSON truncado se o processo parar.
                temporario = arquivo_cache.with_suffix(".tmp")
                temporario.write_text(json.dumps(registro, ensure_ascii=False, indent=2), encoding="utf-8")
                temporario.replace(arquivo_cache)
            return resultado
        except Exception as exc:
            ultimo_erro = exc
            if isinstance(exc, httpx.TimeoutException):
                log_aviso(f"Timeout de rede/API ({type(exc).__name__})")
            codigo = getattr(exc, "code", None)
            if codigo == 400 or "400 INVALID_ARGUMENT" in str(exc):
                raise RuntimeError(
                    "A API rejeitou a requisição com HTTP 400 mesmo sem "
                    "response_schema. Verifique suporte do modelo ao PDF enviado "
                    "e o nome real em GEMINI_MODEL. Erro original: " + str(exc)
                ) from exc
            if isinstance(exc, (ValidationError, ValueError)):
                log_aviso(f"Resposta fora do formato: {str(exc)[:200]}")
                if tentativa >= MAX_TENTATIVAS:
                    raise RuntimeError(
                        "O modelo não conseguiu devolver JSON válido após "
                        f"{MAX_TENTATIVAS} tentativas: {exc}"
                    ) from exc
                # Não substitui valores ou fabrica campos; pede nova geração.
                conteudos_atuais = list(conteudos) + [
                    instrucao,
                    "A resposta anterior não passou na validação JSON/Pydantic. "
                    "Gere novamente o objeto completo, com os tipos exigidos."
                ]
            elif not erro_temporario(exc) or tentativa >= MAX_TENTATIVAS:
                raise
            retry_api = extrair_tempo_retry(exc)
            espera = max(60.0, retry_api or 0.0)
            log_info(f"Nova tentativa em {espera:.0f}s")
            time.sleep(espera)
    raise RuntimeError(f"Falha após {MAX_TENTATIVAS} tentativas: {ultimo_erro}")


# =============================================================================
# 3. SCHEMAS
# =============================================================================

class Evidencia(BaseModel):
    campo: str = "Não informado"
    trecho_original: str = ""
    tipo_informacao: str = "Não informado"
    interpretacao: str = ""


class PerfilVendedor(BaseModel):
    origem: Optional[str] = "Não informado"
    destino: Optional[str] = "Não informado"
    aeroportos_especificos: list[str] = Field(default_factory=list)
    numero_passageiros: Optional[int] = None
    tripulacao: Optional[str] = "Não informado"
    bagagem: Optional[str] = "Não informado"
    distancia_milhas_nauticas: Optional[float] = None
    comprimento_pista_pes: Optional[float] = None
    orcamento_aquisicao: Optional[str] = "Não informado"
    voo_sem_escala: Optional[bool] = None
    objetivo_missao: Optional[str] = "Não informado"
    necessidades_operacionais: list[str] = Field(default_factory=list)
    preferencias_cliente: list[str] = Field(default_factory=list)
    informacoes_nao_informadas: list[str] = Field(default_factory=list)
    contradicoes: list[str] = Field(default_factory=list)
    evidencias: list[Evidencia] = Field(default_factory=list)


class DocumentoVendedor(BaseModel):
    cliente_numero: Optional[int] = None
    perfil: PerfilVendedor
    avisos_validacao: list[str] = Field(default_factory=list)


class AeronaveBCA(BaseModel):
    fabricante: Optional[str] = None
    modelo: str
    categoria_bca: Optional[str] = None
    preco_usd: Optional[float] = None
    assentos_passageiros_max: Optional[int] = None
    nbaa_ifr_range_nm: Optional[float] = None
    tofl_sl_isa_ft: Optional[float] = None
    tofl_5000ft_25c_ft: Optional[float] = None
    pagina_bca: Optional[str] = None
    evidencia_linha: Optional[str] = None
    observacoes_extracao: list[str] = Field(default_factory=list)


class ExtracaoBCA(BaseModel):
    edicao_identificada: Optional[str] = None
    paginas_tabelas_identificadas: list[str] = Field(default_factory=list)
    aeronaves: list[AeronaveBCA] = Field(default_factory=list)
    avisos: list[str] = Field(default_factory=list)
    assinatura_pdf: Optional[str] = None
    escopo_extracao: Optional[str] = None
    versao_extracao: Optional[str] = None


class AnaliseEspecializada(BaseModel):
    area: str
    conclusoes: list[str] = Field(default_factory=list)
    candidatos_relevantes: list[str] = Field(default_factory=list)
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


class AnaliseGemini(BaseModel):
    resumo_executivo: str
    melhor_candidato_preliminar: str = "Nenhum identificado"
    justificativa: str
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


class ResumoConsolidacaoLote(BaseModel):
    lote: str
    resumo: str
    melhor_candidato_deste_lote: str = "Nenhum identificado"
    candidatos_considerados: list[str] = Field(default_factory=list)
    justificativas: list[str] = Field(default_factory=list)
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


# =============================================================================
# 4. LEITURA DO JSON DO AGENTE VENDEDOR
# =============================================================================

def carregar_json_vendedor(caminho: Path) -> DocumentoVendedor:
    if not caminho.is_file():
        raise FileNotFoundError(f"JSON do Agente Vendedor não encontrado: {caminho}")

    with caminho.open("r", encoding="utf-8") as arquivo:
        bruto = json.load(arquivo)

    if not isinstance(bruto, dict):
        raise ValueError("O JSON do vendedor precisa conter um objeto.")

    if "perfil" not in bruto:
        bruto = {
            "cliente_numero": bruto.get("cliente_numero"),
            "perfil": bruto,
        }

    try:
        return DocumentoVendedor.model_validate(bruto)
    except ValidationError as exc:
        raise ValueError(f"JSON do vendedor incompatível com o schema:\n{exc}") from exc


# =============================================================================
# 5. IDENTIFICAÇÃO DAS PÁGINAS E EXTRAÇÃO DO BCA EM LOTES
# =============================================================================

def validar_pdf(caminho: Path) -> dict:
    if not caminho.is_file():
        raise FileNotFoundError(
            f"Não encontrei {caminho.name}. Coloque o PDF na pasta do agente."
        )

    leitor = PdfReader(str(caminho))
    if leitor.is_encrypted:
        raise ValueError("O PDF está protegido por senha.")
    if not leitor.pages:
        raise ValueError("O PDF não contém páginas.")

    paginas_com_texto = sum(
        bool((pagina.extract_text() or "").strip())
        for pagina in leitor.pages
    )
    if paginas_com_texto == 0:
        raise ValueError(
            "Não foi possível extrair texto do PDF. Ele pode ser digitalizado "
            "como imagem; será necessário OCR."
        )

    return {
        "arquivo": caminho.name,
        "paginas_pdf": len(leitor.pages),
        "paginas_com_texto": paginas_com_texto,
        "tamanho_bytes": caminho.stat().st_size,
    }


PROMPT_EXTRACAO_BCA = """
Você é um extrator de dados técnicos de tabelas do Business & Commercial Aviation (BCA).

Analise exclusivamente o PDF/lote de páginas anexado. Extraia TODAS as aeronaves
que ocupam colunas próprias nas tabelas comparativas deste lote, incluindo
pistão, turboélices e jatos executivos. Preserve modelos e variantes distintos.
Não inclua aeronaves que não estejam efetivamente nas tabelas anexadas.

Para cada aeronave, extraia apenas os campos claramente publicados:
- fabricante;
- modelo;
- categoria BCA, se identificável;
- preço equipado em USD;
- maior configuração de assentos de passageiros indicada;
- NBAA IFR Range em milhas náuticas (NM);
- TOFL/Takeoff Field Length ao nível do mar/ISA em pés;
- TOFL a 5.000 ft / 25°C em pés, se existir;
- página impressa do BCA, apenas quando visível;
- transcrição curta da linha/tabela que sustenta a extração.

REGRAS:
1. Não invente, estime, complete nem use conhecimento externo.
2. Não confunda alcance com velocidade, combustível ou outra coluna.
3. Não confunda preço base com preço equipado.
4. Converta números para valores numéricos sem separador de milhar.
5. Campo ausente/ilegível deve ser null, com explicação em observacoes_extracao ou avisos.
6. Não descarte aeronaves por falta de algum campo.
7. Não crie duplicatas; preserve modelos distintos.
8. Não deduza página impressa pelo índice físico do PDF.
9. Se não houver tabela de aeronaves neste lote, retorne aeronaves=[] e explique apenas
   se houver alguma dificuldade real de leitura.
10. Não retorne modelos que não estejam visíveis no lote.
11. Preserve o fabricante e o nome do modelo como aparecem na fonte.
12. Cada coluna de modelo é um registro; não resuma nem omita colunas.
13. Para pistões, o campo NBAA IFR Range pode ser null; não use alcance de outro regime.
14. TOFL pode ter outro nome na tabela; só preencha se a métrica corresponder exatamente.

Responda no schema JSON solicitado. A edição só deve ser informada se estiver
identificável no conteúdo enviado.
""".strip()


def localizar_paginas_candidatas(caminho_pdf: Path) -> tuple[list[int], dict]:
    """
    Procura termos típicos das tabelas no texto extraído do PDF.
    Retorna índices físicos (base zero), incluindo uma página vizinha de cada lado.
    Se a busca textual não localizar termos, usa todas as páginas para não omitir
    silenciosamente conteúdo.
    """
    leitor = PdfReader(str(caminho_pdf))
    paginas_base = []

    for indice, pagina in enumerate(leitor.pages):
        texto = (pagina.extract_text() or "").lower()
        if any(termo in texto for termo in TERMOS_BCA):
            paginas_base.append(indice)

    if not paginas_base:
        paginas = list(range(len(leitor.pages)))
        metodo = "fallback_todas_as_paginas_sem_palavras_chave"
    else:
        conjunto = set()
        for indice in paginas_base:
            conjunto.add(indice)
            if indice > 0:
                conjunto.add(indice - 1)
            if indice + 1 < len(leitor.pages):
                conjunto.add(indice + 1)
        paginas = sorted(conjunto)
        metodo = "palavras_chave_com_paginas_vizinhas"

    return paginas, {
        "metodo_selecao_paginas": metodo,
        "paginas_fisicas_candidatas": [i + 1 for i in paginas],
        "total_paginas_candidatas": len(paginas),
        "termos_busca": list(TERMOS_BCA),
    }


def criar_pdf_lote(caminho_original: Path, indices_paginas: list[int], destino: Path) -> None:
    leitor = PdfReader(str(caminho_original))
    escritor = PdfWriter()
    for indice in indices_paginas:
        escritor.add_page(leitor.pages[indice])
    with destino.open("wb") as arquivo:
        escritor.write(arquivo)


def deduplicar_aeronaves(aeronaves: list[AeronaveBCA]) -> list[AeronaveBCA]:
    unicas: dict[tuple[str, str], AeronaveBCA] = {}
    for aeronave in aeronaves:
        chave = (
            (aeronave.fabricante or "").strip().casefold(),
            aeronave.modelo.strip().casefold(),
        )
        if chave not in unicas:
            unicas[chave] = aeronave
            continue

        # Complementa campos nulos com dados encontrados em outro lote.
        existente = unicas[chave]
        dados = existente.model_dump()
        novos = aeronave.model_dump()
        for campo, valor in novos.items():
            if campo == "observacoes_extracao":
                dados[campo] = list(dict.fromkeys((dados[campo] or []) + (valor or [])))
            elif dados.get(campo) in (None, "", []):
                dados[campo] = valor
        unicas[chave] = AeronaveBCA.model_validate(dados)

    return list(unicas.values())


def extrair_bca_com_gemini(
    caminho_pdf: Path,
    usar_cache: bool = True,
) -> tuple[ExtracaoBCA, dict]:
    PASTA_CACHE.mkdir(parents=True, exist_ok=True)
    cache = PASTA_CACHE / f"{caminho_pdf.stem}_aeronaves_extraidas.json"

    assinatura = hashlib.sha256(caminho_pdf.read_bytes()).hexdigest()

    if usar_cache and cache.is_file():
        try:
            dados = json.loads(cache.read_text(encoding="utf-8"))
            extracao = ExtracaoBCA.model_validate(dados)
            if (extracao.aeronaves
                and extracao.assinatura_pdf == assinatura
                and extracao.escopo_extracao == ESCOPO_AERONAVES
                and extracao.versao_extracao == VERSAO_EXTRACAO):
                log_cache(f"BCA validado e reutilizado: {cache.name}")
                return extracao, {
                    "metodo": "cache_json_validado",
                    "cache": cache.name,
                    "total_lotes_processados": 0,
                }
            log_aviso("Cache incompatível com PDF/escopo/versão; reextraindo")
        except Exception as exc:
            log_aviso(f"Cache inválido ({exc}); reextraindo")

    paginas, info_selecao = localizar_paginas_candidatas(caminho_pdf)
    lotes = [
        paginas[i:i + PAGINAS_POR_LOTE]
        for i in range(0, len(paginas), PAGINAS_POR_LOTE)
    ]

    log_info(f"Páginas candidatas: {len(paginas)} em {len(lotes)} lote(s)")

    # Cache incremental: cada lote concluído é preservado após falhas de rede.
    pasta_lotes = PASTA_CACHE / f"{caminho_pdf.stem}_lotes"
    pasta_lotes.mkdir(parents=True, exist_ok=True)
    chave_execucao = hashlib.sha256(
        f"{assinatura}|{VERSAO_EXTRACAO}|{ESCOPO_AERONAVES}|{MODELO_GEMINI}".encode()
    ).hexdigest()[:16]

    todas_aeronaves: list[AeronaveBCA] = []
    edicoes = []
    paginas_identificadas = []
    avisos = []

    with tempfile.TemporaryDirectory(prefix="bca_lotes_") as pasta_temp:
        pasta_temp_path = Path(pasta_temp)

        for numero_lote, indices in enumerate(lotes, start=1):
            log_sub(
                f"Lote {numero_lote}/{len(lotes)} - "
                f"páginas {', '.join(str(i + 1) for i in indices)}"
            )

            cache_lote = pasta_lotes / f"{chave_execucao}_lote_{numero_lote:03d}.json"
            if cache_lote.is_file():
                try:
                    extraido = ExtracaoBCA.model_validate_json(cache_lote.read_text(encoding="utf-8"))
                    todas_aeronaves.extend(extraido.aeronaves)
                    if extraido.edicao_identificada:
                        edicoes.append(extraido.edicao_identificada)
                    paginas_identificadas.extend(extraido.paginas_tabelas_identificadas)
                    avisos.extend(extraido.avisos)
                    log_cache(f"Lote recuperado: {len(extraido.aeronaves)} aeronaves")
                    continue
                except (ValueError, ValidationError) as exc:
                    log_aviso(f"Cache de lote inválido ({exc}); reprocessando")

            pdf_lote = pasta_temp_path / f"bca_lote_{numero_lote:03d}.pdf"
            criar_pdf_lote(caminho_pdf, indices, pdf_lote)

            arquivo_remoto = None
            try:
                arquivo_remoto = client.files.upload(
                    file=str(pdf_lote),
                    config={"mime_type": "application/pdf"},
                )

                prompt_lote = (
                    PROMPT_EXTRACAO_BCA
                    + "\n\nPáginas físicas deste lote no PDF original (base 1): "
                    + ", ".join(str(i + 1) for i in indices)
                    + ". Use somente as páginas efetivamente visíveis no arquivo."
                    + ("\nESCOPO: extraia APENAS jatos executivos." if ESCOPO_AERONAVES == "jatos" else "\nESCOPO: extraia TODAS as categorias de aeronaves.")
                )

                extraido = gerar_com_controle(
                    [arquivo_remoto, prompt_lote],
                    response_schema=ExtracaoBCA,
                    descricao=f"extração BCA lote {numero_lote}/{len(lotes)}",
                )

                cache_lote.write_text(
                    extraido.model_dump_json(indent=2), encoding="utf-8"
                )
                todas_aeronaves.extend(extraido.aeronaves)
                if extraido.edicao_identificada:
                    edicoes.append(extraido.edicao_identificada)
                paginas_identificadas.extend(extraido.paginas_tabelas_identificadas)
                avisos.extend(extraido.avisos)

                log_ok(f"{len(extraido.aeronaves)} aeronaves identificadas")

            finally:
                if arquivo_remoto is not None:
                    try:
                        client.files.delete(name=arquivo_remoto.name)
                    except Exception as exc:
                        log_aviso(f"Não foi possível excluir o arquivo remoto: {exc}")

    aeronaves_unicas = deduplicar_aeronaves(todas_aeronaves)
    if not aeronaves_unicas:
        raise RuntimeError(
            "Nenhuma aeronave foi extraída. Confira o PDF, as páginas candidatas "
            "e a legibilidade das tabelas."
        )

    extracao_final = ExtracaoBCA(
        edicao_identificada=edicoes[0] if edicoes else None,
        paginas_tabelas_identificadas=list(dict.fromkeys(paginas_identificadas)),
        aeronaves=aeronaves_unicas,
        avisos=list(dict.fromkeys(avisos)),
        assinatura_pdf=assinatura,
        escopo_extracao=ESCOPO_AERONAVES,
        versao_extracao=VERSAO_EXTRACAO,
    )

    cache.write_text(
        json.dumps(
            extracao_final.model_dump(mode="json"),
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    metodo = {
        "metodo": "extracao_pdf_gemini_em_lotes",
        "arquivo_pdf": caminho_pdf.name,
        "cache_criado": cache.name,
        "modelo_extracao": MODELO_GEMINI,
        "escopo_extracao": ESCOPO_AERONAVES,
        "assinatura_pdf": assinatura,
        "total_lotes_processados": len(lotes),
        **info_selecao,
    }
    return extracao_final, metodo


# =============================================================================
# 6. COMPARAÇÕES DETERMINÍSTICAS EM PYTHON
# =============================================================================

def parse_orcamento(texto: Optional[str]) -> Optional[float]:
    if not texto or texto.strip().lower() in {
        "não informado", "nao informado", "none", "null", ""
    }:
        return None

    t = texto.lower().replace(" ", "")
    numeros = re.findall(
        r"\$?\s*(\d+(?:[.,]\d+)?)\s*(m|million|milhão|milhoes|milhões|k)?",
        t,
    )
    valores = []

    for numero, unidade in numeros:
        if "$" not in t and not unidade:
            continue

        valor = float(numero.replace(",", "."))
        if unidade in {"m", "million", "milhão", "milhoes", "milhões"}:
            valor *= 1_000_000
        elif unidade == "k":
            valor *= 1_000
        valores.append(valor)

    return max(valores) if valores else None


def avaliar_aeronave(
    aeronave: AeronaveBCA,
    perfil: PerfilVendedor,
    teto: Optional[float],
) -> dict:
    comparacoes = {}
    restricoes = []
    indefinidos = []

    def avaliar(
        chave: str,
        valor_aeronave,
        valor_missao,
        maior_melhor: bool,
        descricao: str,
    ):
        if valor_aeronave is None or valor_missao is None:
            status = "NAO_VERIFICADO"
            detalhe = f"Comparação não realizada: dado ausente ({descricao})."
            indefinidos.append(chave)
        else:
            atende = (
                valor_aeronave >= valor_missao
                if maior_melhor
                else valor_aeronave <= valor_missao
            )
            status = (
                "ATENDE_REFERENCIA"
                if atende
                else "NAO_ATENDE_REFERENCIA"
            )
            detalhe = (
                f"Aeronave: {valor_aeronave}; requisito/referência: {valor_missao}."
            )
            if not atende:
                restricoes.append(chave)

        comparacoes[chave] = {"status": status, "detalhe": detalhe}

    if teto is None or aeronave.preco_usd is None:
        comparacoes["orcamento"] = {
            "status": "NAO_VERIFICADO",
            "detalhe": "Preço ou orçamento não informado/extraído.",
        }
        indefinidos.append("orcamento")
    else:
        atende = aeronave.preco_usd <= teto
        comparacoes["orcamento"] = {
            "status": "ATENDE_TETO" if atende else "ACIMA_DO_TETO",
            "detalhe": (
                f"Preço BCA USD {aeronave.preco_usd:,.0f}; "
                f"teto informado USD {teto:,.0f}."
            ),
        }
        if not atende:
            restricoes.append("orcamento")

    # Restrição de categoria somente quando expressa na missão ou no escopo.
    texto_requisitos = " ".join([perfil.objetivo_missao or "", *(perfil.necessidades_operacionais or [])]).casefold()
    exige_jato = ESCOPO_AERONAVES == "jatos" or bool(re.search(r"\b(jatos? executivos?|business jets?|executive jets?)\b", texto_requisitos))
    if exige_jato:
        categoria = (aeronave.categoria_bca or "").casefold()
        if not categoria:
            indefinidos.append("categoria_jato")
            comparacoes["categoria_jato"] = {"status": "NAO_VERIFICADO", "detalhe": "Categoria BCA ausente; confirmar se é jato executivo."}
        elif any(termo in categoria for termo in ("turboprop", "turboélice", "turboelice", "piston", "pistão", "pistao")):
            restricoes.append("categoria_jato")
            comparacoes["categoria_jato"] = {"status": "NAO_ATENDE_REFERENCIA", "detalhe": f"Categoria BCA: {aeronave.categoria_bca}."}
        elif any(termo in categoria for termo in ("jet", "jato")):
            comparacoes["categoria_jato"] = {"status": "ATENDE_REFERENCIA", "detalhe": f"Categoria BCA: {aeronave.categoria_bca}."}
        else:
            indefinidos.append("categoria_jato")
            comparacoes["categoria_jato"] = {"status": "NAO_VERIFICADO", "detalhe": f"Categoria ambígua: {aeronave.categoria_bca}."}

    avaliar(
        "passageiros",
        aeronave.assentos_passageiros_max,
        perfil.numero_passageiros,
        True,
        "assentos de passageiros",
    )
    avaliar(
        "alcance_nbaa_ifr",
        aeronave.nbaa_ifr_range_nm,
        perfil.distancia_milhas_nauticas,
        True,
        "NBAA IFR Range (NM)",
    )
    # A pista disponível precisa ser MAIOR ou IGUAL ao TOFL publicado.
    avaliar(
        "pista_sl_isa",
        perfil.comprimento_pista_pes,
        aeronave.tofl_sl_isa_ft,
        True,
        "pista disponível versus TOFL SL/ISA",
    )

    if restricoes:
        classificacao = "COM_RESTRICAO_NA_TRIAGEM"
    elif indefinidos:
        classificacao = "CANDIDATO_COM_PENDENCIAS"
    else:
        classificacao = "CANDIDATO_PRELIMINAR"

    return {
        "fabricante": aeronave.fabricante or "Não identificado",
        "modelo": aeronave.modelo,
        "pagina_bca": aeronave.pagina_bca,
        "categoria_bca": aeronave.categoria_bca,
        "preco_bca_usd": aeronave.preco_usd,
        "assentos_passageiros_max_bca": aeronave.assentos_passageiros_max,
        "nbaa_ifr_range_nm_bca": aeronave.nbaa_ifr_range_nm,
        "tofl_sl_isa_ft_bca": aeronave.tofl_sl_isa_ft,
        "tofl_5000ft_25c_ft_bca": aeronave.tofl_5000ft_25c_ft,
        "evidencia_linha_bca": aeronave.evidencia_linha,
        "observacoes_extracao": aeronave.observacoes_extracao,
        "classificacao_preliminar": classificacao,
        "comparacoes": comparacoes,
        "restricoes_identificadas": restricoes,
        "criterios_nao_verificados": indefinidos,
        "bagagem": (
            "NAO_VERIFICADO - não inferir capacidade a partir do número de assentos."
        ),
        "voo_sem_escala": (
            "NAO_VERIFICADO - requer análise de missão e performance específica."
        ),
    }


def executar_triagem(
    perfil: PerfilVendedor,
    aeronaves: list[AeronaveBCA],
) -> list[dict]:
    teto = parse_orcamento(perfil.orcamento_aquisicao)
    resultados = [
        avaliar_aeronave(aeronave, perfil, teto)
        for aeronave in aeronaves
    ]

    ordem = {
        "CANDIDATO_PRELIMINAR": 0,
        "CANDIDATO_COM_PENDENCIAS": 1,
        "INDETERMINADO": 2,
        "COM_RESTRICAO_NA_TRIAGEM": 3,
    }
    resultados.sort(
        key=lambda item: (
            ordem[item["classificacao_preliminar"]],
            len(item["restricoes_identificadas"]),
            item["preco_bca_usd"] or float("inf"),
        )
    )
    return resultados


# =============================================================================
# 7. ANÁLISES ESPECIALIZADAS GEMINI
# =============================================================================

PROMPTS_ESPECIALIZADOS = {
    "alcance": """
Você é especialista em desempenho e planejamento de alcance de aeronaves.
Analise SOMENTE alcance, rota, NBAA IFR Range e voo sem escala. Use apenas os dados
do pacote. Não invente distância, reservas, ventos, payload, combustível ou performance.
NBAA IFR Range é referência publicada, não garantia de alcance real. Não declare
aptidão operacional. Liste candidatos relevantes, riscos e dados que precisam ser
confirmados. Se a distância da missão estiver ausente, deixe isso explícito.
""".strip(),

    "capacidade": """
Você é especialista em configuração de cabine e capacidade de aeronaves.
Analise SOMENTE passageiros, assentos, tripulação, bagagem e preferências de cabine.
Não infira volume/peso de bagagem a partir de assentos. Não invente capacidade.
Separe o que está publicado no BCA do que precisa ser confirmado com fabricante.
Não declare aptidão operacional.
""".strip(),

    "pista": """
Você é especialista em desempenho de pista de aeronaves.
Analise SOMENTE comprimento de pista disponível e TOFL publicado no BCA.
Compare os valores fornecidos, mas ressalte que TOFL de tabela não substitui
cálculo de performance para peso, altitude, temperatura, vento, declividade,
condição da pista, obstáculos e configuração reais. Não declare aptidão operacional.
""".strip(),

    "consolidacao": """
Você é engenheiro de requisitos aeronáuticos. Consolide as análises especializadas
e os resultados determinísticos calculados em Python. Escolha o melhor candidato
somente entre aeronaves classificadas como CANDIDATO_PRELIMINAR ou CANDIDATO_COM_PENDENCIAS. Se não houver,
use exatamente "Nenhum identificado". Não trate NAO_VERIFICADO como não atendido, nem como comprovadamente atendido.
Não recalcule nem altere preço, alcance, assentos ou TOFL. Não recomende compra
nem declare aptidão operacional. Explique a escolha e as limitações. Responda
em português brasileiro, de forma técnica e objetiva.
""".strip(),
}


def selecionar_resultados_por_area(resultados: list[dict], area: str) -> list[dict]:
    if area == "alcance":
        chaves = {"alcance_nbaa_ifr"}
    elif area == "capacidade":
        chaves = {"passageiros"}
    elif area == "pista":
        chaves = {"pista_sl_isa"}
    else:
        return resultados

    saida = []
    for item in resultados:
        comparacoes = {
            k: v for k, v in item["comparacoes"].items()
            if k in chaves or k == "orcamento"
        }
        saida.append({
            "fabricante": item["fabricante"],
            "modelo": item["modelo"],
            "classificacao_preliminar": item["classificacao_preliminar"],
            "comparacoes_relevantes": comparacoes,
            "restricoes_identificadas": item["restricoes_identificadas"],
            "criterios_nao_verificados": item["criterios_nao_verificados"],
            "dados_bca": {
                "preco_bca_usd": item["preco_bca_usd"],
                "assentos_passageiros_max_bca": item["assentos_passageiros_max_bca"],
                "nbaa_ifr_range_nm_bca": item["nbaa_ifr_range_nm_bca"],
                "tofl_sl_isa_ft_bca": item["tofl_sl_isa_ft_bca"],
                "tofl_5000ft_25c_ft_bca": item["tofl_5000ft_25c_ft_bca"],
                "pagina_bca": item["pagina_bca"],
            },
        })
    return saida


def _perfil_compacto(perfil: PerfilVendedor) -> dict:
    """Perfil sem 'evidencias' (trechos originais) e sem campos vazios: menos tokens."""
    dados = perfil.model_dump(mode="json", exclude={"evidencias"})
    vazios = (None, "", [], "Não informado")
    return {k: v for k, v in dados.items() if v not in vazios}


def separar_candidatos(resultados: list[dict]) -> tuple[list[dict], list[dict]]:
    aprovados = {"CANDIDATO_PRELIMINAR", "CANDIDATO_COM_PENDENCIAS"}
    candidatos = [r for r in resultados if r["classificacao_preliminar"] in aprovados]
    eliminados = [r for r in resultados if r["classificacao_preliminar"] not in aprovados]
    return candidatos, eliminados


def executar_analise_especializada(
    area: str,
    perfil: PerfilVendedor,
    resultados: list[dict],
) -> AnaliseEspecializada:
    """Divide dinamicamente os resultados em chamadas de ate 12.500 tokens estimados."""
    teto = min(12_500, LIMITE_TOKENS_POR_MINUTO)
    perfil_json = _perfil_compacto(perfil)
    itens = selecionar_resultados_por_area(resultados, area)

    def conteudos(grupo):
        pacote = {"area": area, "perfil_missao": perfil_json,
                  "resultados_python_relevantes": grupo}
        return [PROMPTS_ESPECIALIZADOS[area], json.dumps(pacote, ensure_ascii=False)]

    def cabe(grupo):
        entrada = conteudos(grupo)
        # Inclui o schema JSON que gerar_com_controle acrescenta ao prompt.
        instrucao = (
            "Responda EXCLUSIVAMENTE com um único objeto JSON válido, sem markdown, "
            "sem texto antes/depois e sem comentários. Use exatamente estas chaves "
            "e tipos de dados definidos no esquema JSON a seguir. "
            "Para campos opcionais sem evidência, use null; para listas use []. "
            "Não invente informações.\nESQUEMA JSON:\n"
            + json.dumps(AnaliseEspecializada.model_json_schema(), ensure_ascii=False)
        )
        _, estimado = _contar_tokens_com_margem(entrada + [instrucao])
        return estimado <= teto

    lotes = []
    grupo = []
    for item in itens:
        tentativa = grupo + [item]
        if cabe(tentativa):
            grupo = tentativa
        else:
            if not grupo:
                raise RuntimeError(f"Uma unica aeronave excedeu {teto} tokens na area {area}.")
            lotes.append(grupo)
            grupo = [item]
            if not cabe(grupo):
                raise RuntimeError(f"Uma unica aeronave excedeu {teto} tokens na area {area}.")
    if grupo or not lotes:
        lotes.append(grupo)

    log_sub(f"Análise '{area}' - {len(itens)} aeronaves em {len(lotes)} lote(s)")
    parciais = []
    for indice, lote in enumerate(lotes, 1):
        parcial = gerar_com_controle(
            conteudos(lote), response_schema=AnaliseEspecializada,
            descricao=f"analise especializada: {area} - lote {indice}/{len(lotes)}",
        )
        parciais.append(parcial)

    def juntar(campo):
        return list(dict.fromkeys(
            valor for parcial in parciais for valor in getattr(parcial, campo)
        ))

    return AnaliseEspecializada(
        area=area,
        conclusoes=juntar("conclusoes"),
        candidatos_relevantes=juntar("candidatos_relevantes"),
        riscos_tecnicos=juntar("riscos_tecnicos"),
        dados_a_confirmar=juntar("dados_a_confirmar"),
        ressalvas=juntar("ressalvas"),
    )


PROMPT_CONSOLIDACAO_PARCIAL = """
Você é engenheiro de requisitos aeronáuticos.
Analise somente o grupo de aeronaves apresentado e os dados fornecidos.
Considere aeronaves classificadas como CANDIDATO_PRELIMINAR ou CANDIDATO_COM_PENDENCIAS.
Não trate NAO_VERIFICADO como não atendido, nem como comprovadamente atendido.
Não recalcule nem altere preço, alcance, assentos ou TOFL.
Não recomende compra nem declare aptidão operacional.
Identifique o candidato mais promissor DENTRO DESTE GRUPO, justificando com
os dados objetivos. Se nenhum candidato do grupo estiver apto à comparação,
use "Nenhum identificado".
Seja conciso: produza um resumo intermediário para uma consolidação global.
Não repita todos os dados de entrada. Responda em português brasileiro.
""".strip()


def _contar_tokens_com_margem(conteudos) -> tuple[int, int]:
    """
    Estimativa LOCAL (conservadora, ~2,5 caracteres/token) usada só para dimensionar lotes.
    Antes era uma chamada de rede count_tokens por aeronave adicionada ao lote.
    A contagem oficial pela API continua sendo feita em contar_tokens_entrada(),
    imediatamente antes de cada geração.
    """
    texto = "".join(str(c) for c in conteudos)
    total = int(len(texto) / 2.5) + 1
    return total, int(total * MARGEM_CONTAGEM_TOKENS)


def _compactar_analise_especializada(analise: AnaliseEspecializada) -> dict:
    """Remove campos vazios e limita listas para reduzir o contexto da consolidação."""
    dados = analise.model_dump(mode="json")
    compacto = {"area": dados.get("area", "")}
    for campo in (
        "conclusoes", "candidatos_relevantes", "riscos_tecnicos",
        "dados_a_confirmar", "ressalvas"
    ):
        valores = dados.get(campo) or []
        if valores:
            compacto[campo] = valores[:8]
    return compacto


def _compactar_candidato(item: dict) -> dict:
    """Conserva os critérios decisivos e remove texto redundante do pacote LLM."""
    return {
        "fabricante": item.get("fabricante"), "modelo": item.get("modelo"),
        "categoria_bca": item.get("categoria_bca"),
        "classificacao_preliminar": item.get("classificacao_preliminar"),
        "preco_bca_usd": item.get("preco_bca_usd"),
        "assentos_passageiros_max_bca": item.get("assentos_passageiros_max_bca"),
        "nbaa_ifr_range_nm_bca": item.get("nbaa_ifr_range_nm_bca"),
        "tofl_sl_isa_ft_bca": item.get("tofl_sl_isa_ft_bca"),
        "restricoes_identificadas": item.get("restricoes_identificadas", []),
        "criterios_nao_verificados": item.get("criterios_nao_verificados", []),
        "status_criterios": {k: v.get("status") for k, v in item.get("comparacoes", {}).items()},
    }


def _criar_lotes_consolidacao(perfil: PerfilVendedor, candidatos: list[dict]) -> list[list[dict]]:
    """Empacotamento guloso até 12.500 tokens, incluindo instruções e schema."""
    lotes = []
    grupo = []
    schema = json.dumps(ResumoConsolidacaoLote.model_json_schema(), ensure_ascii=False)
    instrucao = "Retorne um objeto JSON válido conforme este esquema: " + schema

    def contar(itens):
        pacote = {"perfil_missao": _perfil_compacto(perfil), "candidatos_preliminares_python": itens}
        return _contar_tokens_com_margem([
            PROMPT_CONSOLIDACAO_PARCIAL, json.dumps(pacote, ensure_ascii=False), instrucao
        ])

    for item in candidatos:
        tentativa = grupo + [item]
        if len(tentativa) <= CANDIDATOS_POR_LOTE_CONSOLIDACAO and contar(tentativa)[1] <= TETO_TOKENS_CONSOLIDACAO:
            grupo = tentativa
        else:
            if not grupo:
                raise RuntimeError(f"Aeronave {item.get('modelo')} excede o teto de tokens.")
            lotes.append(grupo)
            grupo = [item]
            if contar(grupo)[1] > TETO_TOKENS_CONSOLIDACAO:
                raise RuntimeError(f"Aeronave {item.get('modelo')} excede o teto de tokens.")
    if grupo:
        lotes.append(grupo)
    return lotes


def chamar_gemini_analise_final(
    perfil: PerfilVendedor,
    resultados: list[dict],
    analises: list[AnaliseEspecializada],
    fonte_bca: dict,
) -> AnaliseGemini:
    """
    Consolida em duas camadas:
      1) Gemini analisa grupos pequenos de candidatos;
      2) Gemini escolhe globalmente usando somente os resumos intermediários.
    """
    candidatos = [
        _compactar_candidato(item) for item in resultados
        if item["classificacao_preliminar"] in {"CANDIDATO_PRELIMINAR", "CANDIDATO_COM_PENDENCIAS"}
    ]

    resumos_lotes: list[ResumoConsolidacaoLote] = []

    if candidatos:
        lotes = _criar_lotes_consolidacao(perfil, candidatos)
        log_info(f"Consolidação em {len(lotes)} grupo(s)")

        for numero_lote, grupo in enumerate(lotes, start=1):
            pacote_lote = {
                "lote": f"{numero_lote}/{len(lotes)}",
                "perfil_missao": _perfil_compacto(perfil),
                "candidatos_preliminares_python": grupo,
                "regra": (
                    "Avaliar apenas este grupo. A escolha global será feita "
                    "posteriormente a partir dos resumos de todos os grupos."
                ),
            }
            resumo = gerar_com_controle(
                [
                    PROMPT_CONSOLIDACAO_PARCIAL,
                    json.dumps(pacote_lote, ensure_ascii=False),
                ],
                response_schema=ResumoConsolidacaoLote,
                descricao=f"consolidação parcial {numero_lote}/{len(lotes)}",
            )
            resumos_lotes.append(resumo)
            log_ok(
                f"Grupo {numero_lote}/{len(lotes)} - melhor: "
                f"{resumo.melhor_candidato_deste_lote}"
            )
    else:
        log_aviso("Nenhum candidato preliminar para consolidação.")

    pacote_final = {
        "perfil_missao": _perfil_compacto(perfil),
        "fonte_bca": {
            "arquivo_pdf": fonte_bca.get("arquivo_pdf") or fonte_bca.get("arquivo"),
            "edicao_identificada": fonte_bca.get("edicao_identificada"),
            "metodo": fonte_bca.get("metodo"),
        },
        "quantidade_total_aeronaves_avaliadas": len(resultados),
        "quantidade_candidatos_preliminares": len(candidatos),
        "lista_exata_de_candidatos_permitidos": [
            f"{item.get('fabricante', 'Fabricante não identificado')} "
            f"{item.get('modelo', 'Modelo não identificado')}"
            for item in candidatos
        ],
        "resumos_consolidacao_por_lote": [
            item.model_dump(mode="json") for item in resumos_lotes
        ],
        "analises_especializadas": [
            _compactar_analise_especializada(item) for item in analises
        ],
        "regra_de_escolha": (
            "Escolher somente entre os candidatos preliminares mencionados nos "
            "resumos dos lotes. Comparar os melhores candidatos de cada grupo. "
            "Se não houver candidato preliminar, retornar exatamente "
            "'Nenhum identificado'. Não tratar NAO_VERIFICADO como não atendido."
        ),
    }

    prompt_final = (
        PROMPTS_ESPECIALIZADOS["consolidacao"]
        + "\n\nEsta é a consolidação GLOBAL. Os resumos foram produzidos "
          "em grupos separados. Compare os candidatos de todos os grupos. "
          "O nome escolhido deve constar literalmente em "
          "'lista_exata_de_candidatos_permitidos'. Se a lista estiver vazia, "
          "retorne 'Nenhum identificado'. Não invente dados nem reabra critérios "
          "já calculados em Python."
    )
    conteudos_finais = [
        prompt_final,
        json.dumps(pacote_final, ensure_ascii=False),
    ]

    total_final, estimado_final = _contar_tokens_com_margem(conteudos_finais)
    if estimado_final > LIMITE_TOKENS_POR_MINUTO:
        raise RuntimeError(
            f"Mesmo após a consolidação em lotes, o pacote final ficou com "
            f"{estimado_final:,} tokens (limite local: "
            f"{LIMITE_TOKENS_POR_MINUTO:,}). Reduza o tamanho das análises "
            f"especializadas ou a quantidade de itens por resumo."
        )

    return gerar_com_controle(
        conteudos_finais,
        response_schema=AnaliseGemini,
        descricao="consolidação técnica global",
    )


PROMPT_CONSOLIDACAO_RAPIDA = (
    PROMPTS_ESPECIALIZADOS["consolidacao"]
    + "\n\nVocê receberá, num único pacote: a missão do cliente, os candidatos que "
      "passaram na triagem determinística (com status de cada critério) e apenas a "
      "contagem de aeronaves eliminadas por motivo. Avalie alcance, capacidade, pista "
      "e orçamento numa só resposta. O nome escolhido deve constar literalmente em "
      "'lista_exata_de_candidatos_permitidos'. Se a lista estiver vazia, retorne "
      "'Nenhum identificado'. Não invente dados nem reabra critérios já calculados em Python."
)


def consolidar_rapido(
    perfil: PerfilVendedor,
    candidatos: list[dict],
    eliminados: list[dict],
    fonte_bca: dict,
) -> AnaliseGemini:
    """UMA chamada ao modelo, só com o necessário para escolher a aeronave."""
    if not candidatos:
        return AnaliseGemini(
            resumo_executivo=(
                f"Nenhuma das {len(eliminados)} aeronaves do catálogo passou na triagem "
                "determinística para os requisitos informados."
            ),
            melhor_candidato_preliminar="Nenhum identificado",
            justificativa="Todas as aeronaves avaliadas têm ao menos uma restrição calculada em Python.",
            dados_a_confirmar=["Revisar requisitos (orçamento, pista, alcance, passageiros) com o cliente."],
        )

    motivos = {}
    for item in eliminados:
        for restricao in item["restricoes_identificadas"]:
            motivos[restricao] = motivos.get(restricao, 0) + 1

    nomes = [f"{c.get('fabricante') or 'Fabricante não identificado'} {c['modelo']}" for c in candidatos]
    pacote = {
        "perfil_missao": _perfil_compacto(perfil),
        "fonte_bca": {
            "arquivo_pdf": fonte_bca.get("arquivo_pdf") or fonte_bca.get("arquivo"),
            "edicao_identificada": fonte_bca.get("edicao_identificada"),
        },
        "quantidade_total_aeronaves_avaliadas": len(candidatos) + len(eliminados),
        "lista_exata_de_candidatos_permitidos": nomes,
        "candidatos_preliminares_python": [_compactar_candidato(c) for c in candidatos],
        "aeronaves_eliminadas_por_restricao": {"total": len(eliminados), "por_motivo": motivos},
    }
    return gerar_com_controle(
        [PROMPT_CONSOLIDACAO_RAPIDA, json.dumps(pacote, ensure_ascii=False)],
        response_schema=AnaliseGemini,
        descricao="consolidação técnica rápida",
    )


# =============================================================================
# 8. SALVAMENTO DO RELATÓRIO
# =============================================================================

def salvar_relatorio(
    relatorio: dict,
    cliente_numero: Optional[int],
) -> Path:
    PASTA_SAIDA.mkdir(parents=True, exist_ok=True)
    identificador = (
        f"cliente_{cliente_numero:03d}"
        if cliente_numero is not None
        else "cliente_sem_id"
    )
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    destino = (
        PASTA_SAIDA
        / f"{identificador}_triagem_engenheiro_{timestamp}.json"
    )
    destino.write_text(
        json.dumps(relatorio, ensure_ascii=False, indent=4),
        encoding="utf-8",
    )
    return destino


# =============================================================================
# 9. EXECUÇÃO PRINCIPAL
# =============================================================================

def main() -> None:
    log_banner("03 ENGENHEIRO", "Triagem de aeronaves e análise Gemini")
    log_info(f"Modelo: {MODELO_GEMINI}")
    if not MODELO_GEMINI.startswith("gemma-"):
        log_aviso("GEMINI_MODEL está substituindo o padrão Gemma.")

    log_etapa(1, 5, "Leitura do catálogo BCA")
    catalogo = PASTA_CACHE / (PDF_BCA.stem + "_aeronaves_extraidas.json")
    if not catalogo.is_file():
        raise FileNotFoundError(f"Execute a Parte 1 primeiro. Catálogo ausente: {catalogo}")
    extracao = ExtracaoBCA.model_validate_json(catalogo.read_text(encoding="utf-8"))
    aeronaves = extracao.aeronaves
    if not aeronaves:
        raise ValueError("Catálogo sem aeronaves")
    metodo_extracao = {"metodo": "catalogo_json_previamente_extraido", "cache": catalogo.name, "arquivo_pdf": PDF_BCA.name, "total_lotes_processados": 0}
    info_pdf = {"arquivo": PDF_BCA.name, "paginas_pdf": None, "paginas_com_texto": None, "tamanho_bytes": None}
    log_info(f"{len(aeronaves)} aeronaves carregadas")

    log_etapa(2, 5, "Perfil do cliente")
    entrada = input("Caminho do JSON do cliente: ").strip().strip('"')
    if not entrada:
        raise ValueError("Nenhum caminho de JSON foi informado.")

    caminho_json = Path(entrada).expanduser()
    if not caminho_json.is_absolute():
        caminho_json = Path.cwd() / caminho_json

    # Impede usar o catalogo BCA no lugar do perfil do cliente.
    dados_entrada = json.loads(caminho_json.read_text(encoding="utf-8"))
    if isinstance(dados_entrada, dict) and "aeronaves" in dados_entrada and "perfil" not in dados_entrada:
        raise ValueError(
            "Voce informou o JSON do catalogo BCA. Nesta etapa selecione "
            "o JSON de perfil de missao produzido pelo Agente Vendedor."
        )
    documento = carregar_json_vendedor(caminho_json)
    log_info(f"Cliente {documento.cliente_numero}: {caminho_json.name}")

    log_etapa(3, 5, "Triagem em Python")
    resultados = executar_triagem(documento.perfil, aeronaves)

    fonte_bca = {
        **info_pdf,
        **metodo_extracao,
        "edicao_identificada": extracao.edicao_identificada,
        "paginas_tabelas_identificadas": extracao.paginas_tabelas_identificadas,
        "avisos_extracao": extracao.avisos,
    }

    candidatos, eliminados = separar_candidatos(resultados)
    log_info(
        f"{len(resultados)} aeronaves avaliadas: {len(candidatos)} candidata(s), "
        f"{len(eliminados)} eliminada(s)"
    )

    if MODO_RAPIDO and len(candidatos) <= MAX_CANDIDATOS_CHAMADA_UNICA:
        log_etapa(4, 5, "Análises especializadas")
        log_info("Modo rápido: análise única, sem etapas por área.")
        log_etapa(5, 5, "Consolidação da escolha")
        analises = []
        analise_final = consolidar_rapido(documento.perfil, candidatos, eliminados, fonte_bca)
    else:
        log_etapa(4, 5, "Análises especializadas (somente candidatos)")
        PASTA_CACHE_ANALISES.mkdir(parents=True, exist_ok=True)
        assinatura_base = hashlib.sha256(json.dumps({
            "modelo": MODELO_GEMINI,
            "perfil": _perfil_compacto(documento.perfil),
            "resultados": candidatos,
            "prompts": PROMPTS_ESPECIALIZADOS,
        }, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:20]
        arquivos_areas = []
        areas = ("alcance", "capacidade", "pista") if candidatos else ()
        for area in areas:
            arquivo_area = PASTA_CACHE_ANALISES / f"analise_{area}_{assinatura_base}.json"
            if arquivo_area.is_file():
                try:
                    AnaliseEspecializada.model_validate_json(
                        arquivo_area.read_text(encoding="utf-8"))
                    log_cache(f"Análise '{area}' recuperada")
                    arquivos_areas.append(arquivo_area)
                    continue
                except (ValueError, ValidationError) as exc:
                    log_aviso(f"Cache da análise '{area}' inválido ({exc}); recalculando")
            analise_area = executar_analise_especializada(
                area, documento.perfil, candidatos)
            temporario = arquivo_area.with_suffix(".tmp")
            temporario.write_text(
                analise_area.model_dump_json(indent=2), encoding="utf-8")
            temporario.replace(arquivo_area)
            arquivos_areas.append(arquivo_area)
            log_cache(f"Análise '{area}' salva")

        analises = [
            AnaliseEspecializada.model_validate_json(
                caminho.read_text(encoding="utf-8"))
            for caminho in arquivos_areas
        ]
        log_etapa(5, 5, "Consolidação da escolha")
        analise_final = chamar_gemini_analise_final(
            documento.perfil, resultados, analises, fonte_bca)

    # Relatório enxuto: detalhe completo só dos candidatos; eliminadas ficam
    # com os campos que explicam por que saíram.
    resultados_relatorio = candidatos + [
        {
            "fabricante": r["fabricante"], "modelo": r["modelo"],
            "categoria_bca": r["categoria_bca"],
            "classificacao_preliminar": r["classificacao_preliminar"],
            "restricoes_identificadas": r["restricoes_identificadas"],
            "criterios_nao_verificados": r["criterios_nao_verificados"],
        }
        for r in eliminados
    ]

    relatorio = {
        "agente": "Agente Engenheiro - Triagem de Aeronaves",
        "data_processamento": datetime.now().astimezone().isoformat(),
        "cliente_numero": documento.cliente_numero,
        "modelo_gemini": MODELO_GEMINI,
        "configuracao_controle_gemini": {
            "intervalo_minimo_entre_geracoes_segundos":
                MIN_INTERVALO_CHAMADAS_SEGUNDOS,
            "maximo_geracoes_por_minuto": MAX_CHAMADAS_POR_MINUTO,
            "limite_local_tokens_por_minuto": LIMITE_TOKENS_POR_MINUTO,
            "margem_contagem_tokens": MARGEM_CONTAGEM_TOKENS,
            "lotes_paginas_bca": PAGINAS_POR_LOTE,
            "escopo_aeronaves": ESCOPO_AERONAVES,
            "candidatos_por_lote_consolidacao_maximo": CANDIDATOS_POR_LOTE_CONSOLIDACAO,
            "teto_tokens_consolidacao": TETO_TOKENS_CONSOLIDACAO,
            "consolidacao_final_dividida_em_lotes": True,
        },
        "fonte_bca": fonte_bca,
        "metodo_extracao": (
            "PDF BCA filtrado por páginas candidatas, dividido em lotes e "
            "extraído dinamicamente pelo Gemini; comparações feitas em Python."
        ),
        "perfil_missao_recebido": documento.perfil.model_dump(mode="json"),
        "total_aeronaves_extraidas": len(aeronaves),
        **(
            {"catalogo_extraido_bca": [a.model_dump(mode="json") for a in aeronaves]}
            if INCLUIR_CATALOGO_COMPLETO_NO_RELATORIO
            else {"catalogo_extraido_bca_arquivo": catalogo.name}
        ),
        "analises_especializadas": [
            analise.model_dump(mode="json") for analise in analises
        ],
        "analise_gemini": analise_final.model_dump(mode="json"),
        "resultados_triagem": resultados_relatorio,
        "avisos_validacao_vendedor": documento.avisos_validacao,
        "contradicoes_vendedor": documento.perfil.contradicoes,
        "metodologia_e_limitacoes": [
            "Nenhuma aeronave está cadastrada manualmente no código; o catálogo vem do PDF BCA fornecido.",
            "A seleção de páginas usa termos textuais e inclui páginas vizinhas; tabelas sem texto extraível podem não ser selecionadas.",
            "Se nenhum termo for localizado, o agente processa todas as páginas do PDF.",
            "A extração por IA precisa ser conferida contra as tabelas originais.",
            "Campos ausentes ou ilegíveis permanecem null e não são tratados como requisitos atendidos.",
            "NBAA IFR Range e TOFL publicados são referências, não garantias de desempenho operacional.",
            "Bagagem, voo sem escala e aptidão operacional exigem análise específica.",
            "A triagem não substitui AFM/POH, dados do fabricante, cálculo de performance ou despacho operacional.",
        ],
    }

    arquivo = salvar_relatorio(relatorio, documento.cliente_numero)

    log_resultado([
        ("Cliente", documento.cliente_numero),
        ("Aeronaves avaliadas", len(aeronaves)),
        ("Melhor candidato", analise_final.melhor_candidato_preliminar),
        ("Relatório JSON", arquivo.resolve()),
    ])

    print("\nResumo executivo:")
    print(f"  {analise_final.resumo_executivo}")

    log_aviso(
        "Confira a extração das tabelas contra a publicação BCA "
        "antes de qualquer decisão técnica."
    )

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log_aviso("Execução interrompida pelo usuário.")
        sys.exit(130)
    except Exception as exc:
        logging.exception("Erro durante a execução do Agente Engenheiro")
        log_erro(str(exc))
        sys.exit(1)
