"""Assistente PyQt6: múltiplos clientes, etapas independentes e pipeline completo."""

import re

import sys

import shutil

import tempfile

from pathlib import Path

from datetime import datetime
from time import monotonic

from PyQt6.QtCore import QProcess, QProcessEnvironment, Qt, QSize, QTimer

from PyQt6.QtGui import QColor, QTextCursor, QPixmap

from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,

    QGridLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QComboBox,

    QTextEdit, QProgressBar, QMessageBox, QGroupBox, QCheckBox, QListWidget,

    QAbstractItemView, QSplitter, QScrollArea, QSizePolicy, QTabWidget, QDialog)

ROOT = Path(__file__).resolve().parent

PROJECT = ROOT if ROOT.name == 'Assistente_Selecao_Aeronaves' else ROOT.parent

DIRS = [PROJECT / n for n in ('01_clientes', '02_mercado', '03_triagem', '04_relatorio')]

SCRIPTS = ['01_Vendedor.py', '02_Analista_Mercado.py',

           '03_Engenheiro_Requisitos.py', '04_Analista_Relatorio_Final.py']

NAMES = ['01 · Vendedor', '02 · Mercado', '03 · Engenheiro', '04 · Relatório']



class Main(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle('ASSISTENTE DE SELEÇÃO DE AERONAVES EXECUTIVAS')

        self.resize(1160, 920)

        self.process = None

        self.jobs = []

        self.job_idx = 0

        self.cancelled = False

        self.backups = {}

        self.tempdir = None

        self.current = None

        self.before = {}

        self.generated_clients = []

        self.out_buf = ''

        self.failed_docs = []

        self.generated_engineers = []

        self.run_started_at = None
        self.finished_jobs = 0
        self.log_dialog = None
        self._partial = ''
        self.clock = QTimer(self)
        self.init_ui()



    def init_ui(self):

        self.resize(1450, 820)

        self.setMinimumSize(650, 460)

        base = QWidget()

        self.setCentralWidget(base)

        outer = QVBoxLayout(base)

        outer.setContentsMargins(12, 10, 12, 10)

        outer.setSpacing(7)



        header = QLabel('SELEÇÃO DE AERONAVES EXECUTIVAS')

        header.setObjectName('heading')

        outer.addWidget(header)

        subtitle = QLabel('Configure a missão, selecione os agentes e acompanhe cada etapa em tempo real.')

        subtitle.setWordWrap(True)

        outer.addWidget(subtitle)



        # O divisor permite redimensionar manualmente a área de configuração e o terminal.

        splitter = QSplitter(Qt.Orientation.Horizontal)

        splitter.setChildrenCollapsible(False)

        outer.addWidget(splitter, 1)



        scroll = QScrollArea()

        scroll.setWidgetResizable(True)

        scroll.setFrameShape(QScrollArea.Shape.NoFrame)

        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        left = QWidget()

        lv = QVBoxLayout(left)

        lv.setContentsMargins(3, 3, 8, 3)

        lv.setSpacing(8)

        scroll.setWidget(left)

        splitter.addWidget(scroll)



        inputs = QGroupBox('Entradas e clientes')

        iv = QVBoxLayout(inputs)

        iv.setSpacing(6)

        # Texto livre ou documentos: ambos seguem pelo mesmo Agente Vendedor.

        self.source_tabs = QTabWidget()

        text_page = QWidget()

        text_layout = QVBoxLayout(text_page)

        text_layout.setContentsMargins(5, 8, 5, 5)

        text_layout.addWidget(QLabel('Descreva a missão do cliente (origem, destino, passageiros, orçamento, pista etc.):'))

        self.client_text = QTextEdit()

        self.client_text.setObjectName('clientText')

        self.client_text.setPlaceholderText('Exemplo: Preciso de um jato executivo para 6 passageiros, de São Paulo a Manaus, sem escala. Orçamento máximo de US$ 12 milhões, pista de 4.500 ft e lavatório fechado obrigatório.')

        self.client_text.setMinimumHeight(115)

        text_layout.addWidget(self.client_text)

        text_layout.addWidget(QLabel('O texto será convertido temporariamente em DOCX e enviado ao Vendedor, sem alterar o agente.'))

        self.source_tabs.addTab(text_page, 'Digitar missão')



        docs_page = QWidget()

        docs_layout = QVBoxLayout(docs_page)

        docs_layout.setContentsMargins(5, 8, 5, 5)

        doc_buttons = QHBoxLayout()

        add_docs = QPushButton('Adicionar documentos...')

        add_docs.clicked.connect(self.add_docs)

        clear_docs = QPushButton('Limpar')

        clear_docs.clicked.connect(lambda: self.docs.clear())

        doc_buttons.addWidget(add_docs, 2)

        doc_buttons.addWidget(clear_docs, 1)

        docs_layout.addLayout(doc_buttons)

        self.docs = QListWidget()

        self.docs.setMinimumHeight(65)

        self.docs.setMaximumHeight(100)

        self.docs.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)

        docs_layout.addWidget(self.docs)

        remove_docs = QPushButton('Remover selecionados')

        remove_docs.clicked.connect(self.remove_docs)

        docs_layout.addWidget(remove_docs, alignment=Qt.AlignmentFlag.AlignLeft)

        self.source_tabs.addTab(docs_page, 'Arquivos DOCX/PDF')

        iv.addWidget(self.source_tabs)



        grid = QGridLayout()

        grid.setHorizontalSpacing(6)

        grid.setVerticalSpacing(6)

        self.bca = self.file_row(grid, 0, 'BCA (PDF)', 'PDF (*.pdf)',

                                 PROJECT / 'BCA_2026.pdf', always_show_default=True)

        self.client_jsons = self.multi_row(grid, 1, 'JSONs clientes')

        self.engineer_jsons = self.multi_row(grid, 2, 'JSONs triagem')

        iv.addLayout(grid)

        lv.addWidget(inputs)



        self.advanced_button = QPushButton('⚙  Configurações avançadas  ▾')
        self.advanced_button.setObjectName('advancedButton')
        self.advanced_button.setCheckable(True)
        self.advanced_button.setChecked(False)
        lv.addWidget(self.advanced_button)

        sg = QGroupBox('Scripts Python')

        sgrid = QGridLayout(sg)

        sgrid.setHorizontalSpacing(6)

        sgrid.setVerticalSpacing(6)

        self.scripts = [self.file_row(sgrid, i, NAMES[i], 'Python (*.py)', PROJECT / n)

                        for i, n in enumerate(SCRIPTS)]

        lv.addWidget(sg)
        sg.setVisible(False)
        self.advanced_button.toggled.connect(lambda enabled: (
            sg.setVisible(enabled),
            self.advanced_button.setText('⚙  Configurações avançadas  ▴' if enabled else '⚙  Configurações avançadas  ▾')
        ))



        opts = QGroupBox('Etapas a executar (marque apenas as desejadas)')

        og = QGridLayout(opts)

        og.setHorizontalSpacing(10)

        og.setVerticalSpacing(10)

        self.checks = []
        agent_descriptions = (
            'Interpreta a missão e cria o perfil do cliente.',
            'Consulta e prepara o catálogo de aeronaves BCA.',
            'Avalia aeronaves conforme os requisitos da missão.',
            'Produz o relatório final em PDF.'
        )
        agent_labels = ('01  VENDEDOR', '02  MERCADO', '03  ENGENHEIRO', '04  RELATÓRIO')

        for i, name in enumerate(NAMES):
            c = QCheckBox(agent_labels[i])
            c.setObjectName('stageCheck')
            c.setToolTip(agent_descriptions[i] + '\nClique para incluir ou excluir esta etapa.')
            c.setChecked(True)
            c.setMinimumHeight(55)
            c.setCursor(Qt.CursorShape.PointingHandCursor)
            c.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            og.addWidget(c, i // 2, i % 2)
            self.checks.append(c)

        mode_box = QWidget()

        mode_layout = QHBoxLayout(mode_box)

        mode_layout.setContentsMargins(0, 0, 0, 0)

        mode_layout.setSpacing(5)

        mode_layout.addWidget(QLabel('Extração BCA:'))

        self.mode = QComboBox()

        self.mode.addItems(['Python (sem LLM)', 'Modelo (Gemini)'])

        mode_layout.addWidget(self.mode, 1)

        og.addWidget(mode_box, 2, 0)

        self.reuse = QCheckBox('Reutilizar catálogo existente')

        self.reuse.setToolTip('Não executar a etapa Mercado BCA')

        og.addWidget(self.reuse, 2, 1)

        lv.addWidget(opts)

        lv.addStretch(1)



        terminal_panel = QWidget()

        tv = QVBoxLayout(terminal_panel)

        tv.setContentsMargins(6, 3, 3, 3)

        tv.setSpacing(6)

        # Quatro retratos estáticos, sempre visíveis. O agente ativo recebe

        # uma borda circular verde; os demais permanecem neutros.


        portraits = QGridLayout()

        portraits.setSpacing(8)

        self.agent_cards = []

        self.agent_pictures = []

        self.agent_pixmaps = []

        agent_files = ('01_Vendedor.jpg', '02_Mercado.jpg',

                       '03_Engenheiro.jpg', '04_Relatorio.jpg')

        agent_titles = ('Vendedor', 'Mercado', 'Engenheiro', 'Relatório')

        for i, (filename, title_text) in enumerate(zip(agent_files, agent_titles)):

            card = QWidget()

            card.setObjectName('agentCard')

            card.setFixedHeight(185)

            card_layout = QVBoxLayout(card)

            card_layout.setContentsMargins(6, 6, 6, 6)

            card_layout.setSpacing(4)

            picture = QLabel()

            picture.setObjectName('agentPortrait')

            picture.setAlignment(Qt.AlignmentFlag.AlignCenter)

            picture.setMinimumHeight(145)

            picture.setMaximumHeight(145)

            picture.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

            pixmap = QPixmap(str(ROOT / filename))

            self.agent_pixmaps.append(pixmap)

            if pixmap.isNull():

                picture.setText(f'Imagem ausente:\\\n{filename}')

                picture.setWordWrap(True)

            card_layout.addWidget(picture)

            caption = QLabel(title_text)

            caption.setAlignment(Qt.AlignmentFlag.AlignCenter)

            caption.setWordWrap(True)

            card_layout.addWidget(caption)

            portraits.addWidget(card, 0, i)

            self.agent_cards.append(card)

            self.agent_pictures.append(picture)

        tv.addLayout(portraits, 0)

        self.show_agent(None)

        self.terminal = QTextEdit()

        self.terminal.setReadOnly(True)

        self.terminal.setObjectName('terminal')

        self.terminal.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)

        self.terminal.setMinimumHeight(120)

        self.search_log = QLineEdit()
        self.search_log.setPlaceholderText('Pesquisar no log...')
        self.search_log.setMaximumWidth(180)
        self.search_log.returnPressed.connect(self.find_in_log)
        find_button = QPushButton('Buscar')
        find_button.clicked.connect(self.find_in_log)
        expand_button = QPushButton('⛶  Expandir')
        expand_button.clicked.connect(self.expand_terminal)
        tv.addWidget(self.terminal, 1)

        splitter.addWidget(terminal_panel)

        splitter.setStretchFactor(0, 1)

        splitter.setStretchFactor(1, 1)

        splitter.setSizes([650, 750])



        self.labels = []

        stages = QHBoxLayout()

        stages.setSpacing(6)

        for name in NAMES:

            lab = QLabel(name + ' · Pendente')

            lab.setObjectName('stage')

            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)

            lab.setWordWrap(True)

            stages.addWidget(lab, 1)

            self.labels.append(lab)

        outer.addLayout(stages)

        self.progress = QProgressBar()

        outer.addWidget(self.progress)

        controls = QHBoxLayout()

        controls.setSpacing(6)

        self.start = QPushButton('▶ Executar etapas selecionadas')

        self.start.clicked.connect(self.begin)

        self.stop = QPushButton('■ Interromper')

        self.stop.clicked.connect(self.abort)

        self.stop.setEnabled(False)

        save = QPushButton('Salvar log')

        save.clicked.connect(self.save_log)

        clear = QPushButton('Limpar terminal')

        clear.clicked.connect(lambda: self.terminal.clear())

        for btn in (self.start, self.stop, save, clear):

            btn.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)

            controls.addWidget(btn, 1)

        outer.addLayout(controls)

        self.statusBar().showMessage('Pronto  •  Ambiente preparado para executar os agentes')

        self.setStyleSheet('''
            QMainWindow, QWidget { background: #f5f7fb; color: #1f2937; font-size: 12px; }
            QLabel#heading { font-size: 19px; font-weight: bold; color: #142d4e; padding: 4px 0; }
            QGroupBox { border: 1px solid #d5dce5; border-radius: 8px; margin-top: 12px;
                        padding-top: 10px; font-weight: bold; background: #ffffff; }
            QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px;
                               background: #ffffff; color: #1f2937; }
            QLineEdit, QComboBox, QListWidget, QTextEdit#clientText {
                background: #ffffff; border: 1px solid #cbd5e1;
                border-radius: 5px; padding: 5px; color: #111827;
                selection-background-color: #bfdbfe; selection-color: #111827;
            }
            QTabWidget::pane { border: 1px solid #d5dce5; background: #ffffff; }
            QTabBar::tab { background: #f1f5f9; color: #334155; border: 1px solid #d5dce5;
                           padding: 7px 12px; }
            QTabBar::tab:selected { background: #ffffff; color: #1d4ed8;
                                    border-bottom-color: #ffffff; }
            QPushButton { background: #e8eef6; color: #1f2937; border: 1px solid #cbd5e1;
                          border-radius: 6px; padding: 8px 8px; }
            QPushButton:hover { background: #dbeafe; border-color: #93c5fd; }
            QPushButton:pressed { background: #bfdbfe; }
            QPushButton:disabled { color: #94a3b8; background: #f1f5f9; border-color: #e2e8f0; }
            QCheckBox { color: #1f2937; spacing: 8px; }
            QCheckBox#stageCheck {
                background: #f8fafc; color: #64748b;
                border: 2px solid #dbe2ea; border-radius: 11px;
                padding: 10px 12px; font-size: 12px; font-weight: 700;
                spacing: 11px;
            }
            QCheckBox#stageCheck:hover { background: #eff6ff; border-color: #93c5fd; }
            QCheckBox#stageCheck:checked {
                background: #eff6ff; color: #1d4ed8; border-color: #3b82f6;
            }
            QCheckBox#stageCheck::indicator { width: 21px; height: 21px; }
            QCheckBox#stageCheck::indicator:unchecked {
                background: #ffffff; border: 2px solid #94a3b8; border-radius: 6px;
            }
            QCheckBox#stageCheck::indicator:unchecked:hover { border-color: #3b82f6; }
            QCheckBox#stageCheck::indicator:checked {
                background: #2563eb; border: 2px solid #2563eb; border-radius: 6px;
            }
            QLabel#metric { background: #ffffff; color: #142d4e; font-weight: 700;
                            border: 1px solid #e2e8f0; border-radius: 9px;
                            padding: 11px 4px; }
            QPushButton#advancedButton { background: #ffffff; text-align: left;
                color: #1d4ed8; font-weight: 600; border: 1px solid #d5dce5; }
            QLabel#stage { background: #f8fafc; color: #334155; border: 1px solid #d5dce5;
                           border-radius: 7px; padding: 7px 3px; }
            QTextEdit#terminal { background: #080f1c; color: #c4f1d0; border: 1px solid #374151;
                                 font-family: Consolas, monospace; font-size: 12px;
                                 selection-background-color: #2563eb; selection-color: #ffffff; }
            QProgressBar { background: #f1f5f9; color: #1f2937; border: 1px solid #cbd5e1;
                           border-radius: 4px; text-align: center; min-height: 15px; }
            QProgressBar::chunk { background: #22c55e; }
            QSplitter::handle { background: #d5dce5; width: 5px; }
            QScrollArea { border: none; background: #ffffff; }
            QStatusBar { background: #ffffff; color: #475569; }
            QScrollBar { background: #f8fafc; }
        ''')

    def find_in_log(self):
        term = self.search_log.text().strip()
        if not term:
            return
        if not self.terminal.find(term):
            cursor = self.terminal.textCursor()
            cursor.movePosition(QTextCursor.MoveOperation.Start)
            self.terminal.setTextCursor(cursor)
            self.terminal.find(term)

    def expand_terminal(self):
        """Janela independente: amplia o console sem reduzir os retratos."""
        if self.log_dialog is None:
            self.log_dialog = QDialog(self)
            self.log_dialog.setWindowTitle('Terminal expandido')
            self.log_dialog.resize(1050, 700)
            layout = QVBoxLayout(self.log_dialog)
            self.expanded_text = QTextEdit()
            self.expanded_text.setReadOnly(True)
            self.expanded_text.setStyleSheet(
                'background: #080f1c; color: #c4f1d0; '
                'font: 12px Consolas; border-radius: 8px; padding: 12px;')
            layout.addWidget(self.expanded_text)
        self.expanded_text.setPlainText(self.terminal.toPlainText())
        self.expanded_text.moveCursor(QTextCursor.MoveOperation.End)
        self.log_dialog.show()
        self.log_dialog.raise_()
        self.log_dialog.activateWindow()

    def file_row(self, grid, row, title, filt, default=None, always_show_default=False):

        grid.addWidget(QLabel(title), row, 0)

        entry = QLineEdit(str(default) if default and (always_show_default or Path(default).is_file()) else '')

        entry.setMinimumWidth(0)

        entry.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)

        grid.addWidget(entry, row, 1)

        btn = QPushButton('Procurar...')

        btn.clicked.connect(lambda: self.pick_file(entry, filt))

        grid.addWidget(btn, row, 2); grid.setColumnStretch(1, 1)

        return entry



    def multi_row(self, grid, row, title):

        grid.addWidget(QLabel(title), row, 0)

        entry = QLineEdit(); entry.setPlaceholderText('Opcional: um ou vários JSONs')

        entry.setMinimumWidth(0)

        entry.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)

        grid.addWidget(entry, row, 1)

        btn = QPushButton('Selecionar vários...')

        btn.clicked.connect(lambda: self.pick_multiple(entry))

        grid.addWidget(btn, row, 2)

        return entry



    def pick_file(self, entry, filt):

        p, _ = QFileDialog.getOpenFileName(self, 'Selecionar arquivo', entry.text() or str(PROJECT), filt)

        if p: entry.setText(p)



    def pick_multiple(self, entry):

        paths, _ = QFileDialog.getOpenFileNames(self, 'Selecionar JSONs', str(PROJECT), 'JSON (*.json)')

        if paths: entry.setText(' ; '.join(paths))



    def add_docs(self):

        paths, _ = QFileDialog.getOpenFileNames(self, 'Selecionar documentos de clientes', str(PROJECT),

                                                 'Documentos (*.docx *.pdf)')

        existing = {self.docs.item(i).text() for i in range(self.docs.count())}

        for p in paths:

            if p not in existing: self.docs.addItem(p)



    def remove_docs(self):

        for item in self.docs.selectedItems(): self.docs.takeItem(self.docs.row(item))



    def log(self, msg, color=None):

        cursor = self.terminal.textCursor(); cursor.movePosition(QTextCursor.MoveOperation.End)

        fmt = cursor.charFormat(); fmt.setForeground(QColor(color or '#c4f1d0'))

        cursor.insertText(msg, fmt); self.terminal.setTextCursor(cursor)
        if self.log_dialog is not None and self.log_dialog.isVisible():
            self.expanded_text.setPlainText(self.terminal.toPlainText())
            self.expanded_text.moveCursor(QTextCursor.MoveOperation.End)

        self.terminal.ensureCursorVisible()



    def mark(self, i, status): self.labels[i].setText(NAMES[i] + ' · ' + status)



    @staticmethod

    def parse_jsons(entry):

        return [Path(x.strip().strip('"')).expanduser().resolve()

                for x in entry.text().split(';') if x.strip()]



    @staticmethod

    def is_client_json(p):

        """JSON de perfil do Vendedor: qualquer .json da pasta, exceto resumo e arquivos de erro."""

        return p.name != 'resumo_processamento.json' and not p.name.endswith('_erro.json')



    @staticmethod

    def snapshot(folder, pattern, keep=None):

        return {str(p.resolve()): p.stat().st_mtime_ns for p in folder.glob(pattern)

                if p.is_file() and (keep is None or keep(p))}



    @staticmethod

    def changed(folder, pattern, before, keep=None):

        return sorted([p for p in folder.glob(pattern) if p.is_file() and (keep is None or keep(p)) and

                       (str(p.resolve()) not in before or p.stat().st_mtime_ns != before[str(p.resolve())])],

                      key=lambda p: p.stat().st_mtime_ns)



    def begin(self):

        try:

            selected = [i for i, c in enumerate(self.checks) if c.isChecked()]

            if self.reuse.isChecked() and 1 in selected: selected.remove(1)

            if not selected: raise ValueError('Marque ao menos uma etapa para executar.')

            self.paths = [Path(e.text().strip().strip('"')).expanduser().resolve() if e.text().strip() else None

                          for e in self.scripts]

            for i in selected:

                if self.paths[i] is None or not self.paths[i].is_file():

                    raise FileNotFoundError(f'Selecione o script da etapa {i+1}.')

            docs = [Path(self.docs.item(i).text()).resolve() for i in range(self.docs.count())]

            clients = self.parse_jsons(self.client_jsons)

            engineers = self.parse_jsons(self.engineer_jsons)

            for p in docs + clients + engineers:

                if not p.is_file(): raise FileNotFoundError(f'Arquivo não encontrado: {p}')

            text_mode = self.source_tabs.currentIndex() == 0

            mission_text = self.client_text.toPlainText().strip() if text_mode else ''

            if 0 in selected and text_mode and not mission_text:

                raise ValueError('Digite a missão do cliente ou selecione a aba Arquivos DOCX/PDF.')

            if 0 in selected and not text_mode and not docs:

                raise ValueError('Adicione ao menos um documento de cliente para executar o Vendedor.')

            if 2 in selected and 0 not in selected and not clients:

                raise ValueError('Para executar o Engenheiro sem Vendedor, selecione JSONs de clientes.')

            if 3 in selected and 2 not in selected and not engineers:

                raise ValueError('Para executar Relatório sem Engenheiro, selecione JSONs de triagem.')

            bca_text = self.bca.text().strip().strip('"')

            self.bca_path = Path(bca_text).expanduser().resolve() if bca_text else None

            if 1 in selected and (self.bca_path is None or not self.bca_path.is_file()):

                raise ValueError('Selecione o PDF BCA para executar o Mercado.')

            if self.bca_path and not self.bca_path.is_file():

                raise FileNotFoundError(f'PDF BCA não encontrado: {self.bca_path}')

            for folder in DIRS: folder.mkdir(parents=True, exist_ok=True)

            self.tempdir = tempfile.TemporaryDirectory(prefix='agentes_gui_')

            if 0 in selected and text_mode:

                try:

                    from docx import Document

                    doc = Document()

                    doc.add_heading('Requisitos da missão do cliente', level=1)

                    for paragraph in mission_text.splitlines():

                        if paragraph.strip():

                            doc.add_paragraph(paragraph.strip())

                    text_file = Path(self.tempdir.name) / ('missao_digitada_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.docx')

                    doc.save(text_file)

                    docs = [text_file]

                except Exception:

                    self.tempdir.cleanup()

                    self.tempdir = None

                    raise

            self.backups = {}; self.cancelled = False

            self.generated_clients = []; self.generated_engineers = []

            self.failed_docs = []

            self.use_clients = clients; self.use_engineers = engineers

            self.selected = selected

            self.jobs = []

            if 0 in selected:

                self.jobs.extend({'step': 0, 'input': d} for d in docs)

            if 1 in selected:

                self.jobs.append({'step': 1, 'input': None})

            if 2 in selected:

                # Vendedor gera arquivos dinamicamente: inserir tarefas depois da etapa 01.

                if 0 not in selected:

                    self.jobs.extend({'step': 2, 'input': p} for p in clients)

            if 3 in selected and 2 not in selected:

                self.jobs.extend({'step': 3, 'input': p} for p in engineers)

            self.job_idx = 0

            self.progress.setRange(0, max(len(self.jobs), 1)); self.progress.setValue(0)

            for i in range(4): self.mark(i, 'Aguardando' if i in selected else 'Ignorado')

            if self.reuse.isChecked(): self.mark(1, 'Reutilizado')

            self.start.setEnabled(False); self.stop.setEnabled(True)
            self.run_started_at = monotonic()
            self.finished_jobs = 0
            self.clock.start(1000)

            self.log('\n' + '='*70 + '\nPIPELINE | Nova execução - ' + datetime.now().isoformat(timespec='seconds') + '\n' + '='*70 + '\n', '#60a5fa')

            self.next_job()

        except Exception as exc:

            if self.tempdir: self.tempdir.cleanup(); self.tempdir = None

            QMessageBox.critical(self, 'Erro de configuração', str(exc))



    def stage_file(self, source, target):

        source, target = Path(source).resolve(), Path(target).resolve()

        if source == target: return

        if not source.is_file(): raise FileNotFoundError(f'Entrada ausente: {source}')

        target.parent.mkdir(parents=True, exist_ok=True)

        if target not in self.backups:

            if target.exists():

                backup = Path(self.tempdir.name) / ('backup_' + str(len(self.backups)))

                shutil.copy2(target, backup); self.backups[target] = backup

            else: self.backups[target] = None

        shutil.copy2(source, target)




    def show_agent(self, step):

        """Destaca com contorno circular o retrato do agente em execução."""

        for i, card in enumerate(self.agent_cards):

            active = i == step

            card.setStyleSheet(

                'QWidget#agentCard { background: #f0fdf4; '

                'border: 3px solid #22c55e; border-radius: 22px; }'

                if active else

                'QWidget#agentCard { background: #ffffff; '

                'border: 2px solid #d5dce5; border-radius: 22px; }'

            )

        self.scale_agent_images()



    def scale_agent_images(self):

        for label, pixmap in zip(self.agent_pictures, self.agent_pixmaps):

            if pixmap.isNull():

                continue

            width = max(65, label.width() - 8)

            height = 145

            label.setPixmap(pixmap.scaled(

                width, height, Qt.AspectRatioMode.KeepAspectRatio,

                Qt.TransformationMode.SmoothTransformation))



    def resizeEvent(self, event):

        super().resizeEvent(event)

        if hasattr(self, 'agent_pictures'):

            self.scale_agent_images()



    def job_position(self):
        """Posição (n, total) da tarefa atual entre as tarefas do MESMO agente."""
        step = self.current['step']
        same = [j for j in self.jobs if j['step'] == step]
        pos = next((i for i, j in enumerate(same, 1) if j is self.current), 1)
        total = len(same)
        # O Relatório entra na fila um a um, depois de cada triagem:
        # o total esperado é o número de triagens.
        if step == 3 and 2 in self.selected:
            total = max(total, sum(1 for j in self.jobs if j['step'] == 2))
        return pos, max(total, pos)

    def note(self, msg, color='#93c5fd'):
        """Linha do pipeline, no mesmo padrão dos agentes."""
        self.log(f'[PIPELINE] {msg}\n', color)

    def log_agent(self, texto, final=False):
        """Saída dos agentes, colorida pelas etiquetas padrão (linha a linha)."""
        linhas = (self._partial + texto).splitlines(keepends=True)
        self._partial = ''
        if linhas and not linhas[-1].endswith('\n') and not final:
            self._partial = linhas.pop()  # linha incompleta: espera o resto
        for linha in linhas:
            inicio = linha.lstrip()
            if inicio.startswith('[ERRO]'):
                cor = '#f87171'
            elif inicio.startswith('[AVISO]'):
                cor = '#fbbf24'
            elif inicio.startswith(('[OK]', 'RESULTADO')):
                cor = '#4ade80'
            elif inicio.startswith(('[API]', '[CACHE]')):
                cor = '#94a3b8'
            elif inicio.startswith(('=', '> ')) or re.match(r'\[\d+/\d+\]', inicio):
                cor = '#60a5fa'
            else:
                cor = None
            self.log(linha, cor)

    def next_job(self):

        if self.cancelled: return

        if self.job_idx >= len(self.jobs):

            if getattr(self, 'failed_docs', None):

                self.log('\n[AVISO] Finalizado com falhas no Vendedor: ' + ', '.join(self.failed_docs) + '\n', '#fbbf24')

                self.finish(success=False); return

            self.log('\n[PIPELINE] Etapas selecionadas concluídas com sucesso\n', '#4ade80')

            self.finish(success=True); return

        job = self.jobs[self.job_idx]

        self.current = job; step = job['step']; inp = job['input']; script = self.paths[step]

        self.show_agent(step)

        try:

            self.before = {}

            args = ['-u', str(script)]

            stdin = None

            if step == 0:

                self.before = self.snapshot(DIRS[0], '*.json', self.is_client_json)

                stdin = str(inp)

            elif step == 1:

                self.stage_file(self.bca_path, script.parent / 'BCA_2026.pdf')

                self.before = self.snapshot(DIRS[1], 'BCA_2026_aeronaves_extraidas*.json')

                args += ['--modo', 'modelo' if self.mode.currentIndex() else 'python']

            elif step == 2:

                catalog = DIRS[1] / 'BCA_2026_aeronaves_extraidas.json'

                if not catalog.is_file():

                    raise FileNotFoundError(f'Catálogo BCA ausente: {catalog}. Execute Mercado ou forneça um catálogo existente.')

                # Não sobrescreve o catálogo persistente; copia apenas para o local legado quando necessário.

                if script.parent != PROJECT:

                    self.stage_file(catalog, script.parent / '02_mercado' / catalog.name)

                if self.bca_path:

                    self.stage_file(self.bca_path, script.parent / 'BCA_2026.pdf')

                self.before = self.snapshot(DIRS[2], '*_triagem_engenheiro*.json')

                stdin = str(inp)

            elif step == 3:

                self.before = self.snapshot(DIRS[3], '*.pdf')

                args.append(str(inp))

            pos, total = self.job_position()

            self.mark(step, f'Executando ({pos}/{total})')

            self.statusBar().showMessage(f'Executando {NAMES[step]} ({pos}/{total})')

            self.log(f'\n[PIPELINE] {NAMES[step]} ({pos}/{total}) - '
                     f'{Path(inp).name if inp else "catálogo BCA"}\n', '#fbbf24')

            self.out_buf = ''

            self.process = QProcess(self)

            self.process.setWorkingDirectory(str(script.parent))

            self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)

            env = QProcessEnvironment.systemEnvironment()

            env.insert('PYTHONUNBUFFERED', '1'); env.insert('PYTHONIOENCODING', 'utf-8')

            self.process.setProcessEnvironment(env)

            self.process.readyReadStandardOutput.connect(self.read_output)

            self.process.finished.connect(self.process_finished)

            self.process.errorOccurred.connect(self.process_error)

            self.process.start(sys.executable, args)

            if not self.process.waitForStarted(5000):

                raise RuntimeError('Não foi possível iniciar o processo Python.')

            if stdin is not None: self.process.write((stdin + '\n').encode('utf-8'))

        except Exception as exc:

            self.fail(str(exc))



    def read_output(self):

        if self.process:

            texto = bytes(self.process.readAllStandardOutput()).decode('utf-8', errors='replace')

            self.out_buf += texto

            self.log_agent(texto)



    def reason_from_output(self):

        """Motivo real da falha do Vendedor (ele devolve código 0 mesmo quando falha)."""

        achados = re.findall(r'\[ERRO\] (?:Cliente \d+/\d+|Execu[çc][ãa]o) - (.+)', self.out_buf)

        return achados[-1].strip() if achados else 'sem detalhes — veja o console acima'



    def process_error(self, error): self.log(f'\n[ERRO] Processo - {error}\n', '#f87171')



    def process_finished(self, code, status):

        self.read_output()
        self.log_agent('', final=True)

        if self.cancelled: self.finish(); return

        if code != 0 or status != QProcess.ExitStatus.NormalExit:

            self.fail(f'Etapa {self.current["step"]+1} terminou com código {code}.'); return

        try:

            step = self.current['step']

            if step == 0:

                results = self.changed(DIRS[0], '*.json', self.before, self.is_client_json)

                if not results:

                    nome = Path(self.current['input']).name

                    motivo = self.reason_from_output()

                    self.failed_docs.append(nome)

                    self.log(f'\n[ERRO] Vendedor não gerou JSON para {nome} - {motivo}\n', '#f87171')

                    self.mark(0, f'Falhou em {len(self.failed_docs)} documento(s)')

                    self.job_idx += 1

                    self.progress.setValue(self.job_idx)

                    self.next_job()

                    return

                self.generated_clients.extend(results)

                for r in results: self.note(f'Gerado: {r.name}')

            elif step == 1:

                catalog = DIRS[1] / 'BCA_2026_aeronaves_extraidas.json'

                if not catalog.is_file(): raise RuntimeError('Catálogo BCA não encontrado em 02_mercado.')

                self.note(f'Catálogo: {catalog.name}')

            elif step == 2:

                results = self.changed(DIRS[2], '*_triagem_engenheiro*.json', self.before)

                if not results: raise RuntimeError('Engenheiro não gerou novo JSON em 03_triagem.')

                self.generated_engineers.extend(results)

                self.note(f'Gerado: {results[-1].name}')

                if 3 in self.selected:

                    # Insere relatório imediatamente após a triagem correspondente.

                    self.jobs[self.job_idx+1:self.job_idx+1] = [

                        {'step': 3, 'input': p} for p in results]

            elif step == 3:

                results = self.changed(DIRS[3], '*.pdf', self.before)

                if not results: raise RuntimeError('Relatório não gerou PDF novo em 04_relatorio.')

                self.note(f'Gerado: {results[-1]}', '#4ade80')

            self.mark(step, 'Concluído')

            self.job_idx += 1

            # Depois de todos os Vendedores e Mercado, inserir Engenheiros para cada JSON.

            if step in (0, 1) and 2 in self.selected and not any(j['step'] == 2 for j in self.jobs):

                no_more_preparation = not any(j['step'] in (0, 1) for j in self.jobs[self.job_idx:])

                if no_more_preparation:

                    all_clients = list(dict.fromkeys(self.generated_clients + self.use_clients))

                    if not all_clients: raise RuntimeError('Nenhum JSON de cliente disponível para o Engenheiro.')

                    self.jobs.extend({'step': 2, 'input': p} for p in all_clients)

            self.progress.setRange(0, max(len(self.jobs), 1))

            self.progress.setValue(self.job_idx)
            self.next_job()

        except Exception as exc: self.fail(str(exc))



    def fail(self, msg):

        if self.current: self.mark(self.current['step'], 'Falhou')

        self.log('\n[ERRO] ' + msg + '\n', '#f87171')

        self.statusBar().showMessage('Falha: ' + msg)

        self.finish()



    def abort(self):

        self.cancelled = True

        self.log('\n[AVISO] Interrupção solicitada.\n', '#fbbf24')

        if self.process and self.process.state() != QProcess.ProcessState.NotRunning:

            self.process.kill()

        else: self.finish()



    def finish(self, success=False):

        for target, backup in reversed(list(self.backups.items())):

            try:

                if backup is None: target.unlink(missing_ok=True)

                else: shutil.copy2(backup, target)

            except Exception as exc: self.log(f'[AVISO] Não foi possível restaurar {target}: {exc}\n', '#fbbf24')

        self.backups.clear()

        if self.tempdir: self.tempdir.cleanup(); self.tempdir = None

        self.start.setEnabled(True); self.stop.setEnabled(False)

        self.show_agent(None)

        if self.cancelled: self.statusBar().showMessage('Execução interrompida')

        elif success: self.statusBar().showMessage('Etapas concluídas com sucesso')



    def save_log(self):

        name = 'pipeline_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.log'

        p, _ = QFileDialog.getSaveFileName(self, 'Salvar log', str(PROJECT / name), 'Log (*.log);;Texto (*.txt)')

        if p:

            Path(p).write_text(self.terminal.toPlainText(), encoding='utf-8')

            self.statusBar().showMessage(f'Log salvo: {p}')



    def closeEvent(self, event):

        if self.process and self.process.state() != QProcess.ProcessState.NotRunning:

            QMessageBox.warning(self, 'Processo em andamento', 'Interrompa o processo antes de fechar.')

            event.ignore(); return

        event.accept()



if __name__ == '__main__':

    app = QApplication(sys.argv)

    win = Main(); win.show()

    sys.exit(app.exec())
