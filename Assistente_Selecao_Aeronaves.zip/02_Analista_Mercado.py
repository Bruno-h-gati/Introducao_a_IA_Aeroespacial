# -*- coding: utf-8 -*-
"""
AGENTE ENGENHEIRO - triagem preliminar de aeronaves usando BCA em PDF.

Arquivos na mesma pasta:
  - agente_engenheiro_gemini.py
  - BCA_2026.pdf

Dependências:
  pip install -U pydantic pypdf pdfplumber   (google-genai só p/ análises com LLM)

Configuração no PowerShell:
  setx GEMINI_API_KEY "SUA_CHAVE_API"
  setx GEMINI_MODEL "gemma-4-31b-it"

Feche e reabra o terminal após usar setx.

Arquitetura:
  1. Identifica páginas potencialmente relacionadas às tabelas de jatos.
  2. Divide as páginas candidatas em lotes e extrai o BCA dinamicamente com Gemini.
  3. Salva o catálogo extraído em cache JSON para reutilização.
  4. Faz comparações objetivas em Python.
  5. Executa análises especializadas: alcance, capacidade, pista e consolidação.
  6. Controla chamadas de geração: intervalo mínimo de 30 s, no máximo 2/min
     e teto local conservador de 14.000 tokens/min.

Observação sobre limites:
- O controle de 30 segundos é aplicado às chamadas generate_content.
- count_tokens e upload/delete de arquivos são operações separadas da geração.
- A quota real depende do projeto, modelo e nível de faturamento no Google AI.
- O limite local de 14.000 tokens/min é uma proteção conservadora, não uma
  declaração da quota oficial da conta.
"""

from __future__ import annotations

import argparse
import json
import hashlib
import httpx
import pdfplumber
import logging
import os
import random
import re
import sys
import tempfile
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Optional

try:
    from google import genai
    from google.genai import types
except ImportError:  # extração do BCA não depende mais do Gemini
    genai = types = None
from pydantic import BaseModel, Field, ValidationError
from pypdf import PdfReader, PdfWriter


# =============================================================================
# PADRÃO DE SAÍDA NO TERMINAL (bloco idêntico nos quatro agentes)
# Sem símbolos fora do cp1252, para não falhar em consoles Windows.
# =============================================================================

_LARGURA_LOG = 70


def log_banner(agente: str, descricao: str = "") -> None:
    print("=" * _LARGURA_LOG)
    print(f"{agente} | {descricao}" if descricao else agente)
    print("=" * _LARGURA_LOG, flush=True)


def log_etapa(atual: int, total: int, texto: str) -> None:
    print(f"\n[{atual}/{total}] {texto}", flush=True)


def log_sub(texto: str) -> None:
    print(f"\n> {texto}", flush=True)


def log_info(texto: str) -> None:
    print(f"  {texto}", flush=True)


def log_api(texto: str) -> None:
    print(f"  [API] {texto}", flush=True)


def log_cache(texto: str) -> None:
    print(f"  [CACHE] {texto}", flush=True)


def log_ok(texto: str) -> None:
    print(f"  [OK] {texto}", flush=True)


def log_aviso(texto: str) -> None:
    print(f"  [AVISO] {texto}", flush=True)


def log_erro(texto: str) -> None:
    print(f"\n[ERRO] {texto}", flush=True)


def log_resultado(itens: list[tuple[str, object]]) -> None:
    largura = max((len(str(k)) for k, _ in itens), default=0)
    print("\n" + "-" * _LARGURA_LOG)
    print("RESULTADO")
    for chave, valor in itens:
        print(f"  {str(chave).ljust(largura)} : {valor}")
    print("-" * _LARGURA_LOG, flush=True)


# =============================================================================
# 1. CONFIGURAÇÕES
# =============================================================================

# Diretório onde está o script
BASE_DIR = Path(__file__).resolve().parent

# Identifica a raiz do projeto
if BASE_DIR.name == "Projeto_Final_Gemini":
    PASTA_PROJETO = BASE_DIR
else:
    PASTA_PROJETO = BASE_DIR.parent

# Diretório de saída do Analista de Mercado
PASTA_SAIDA = PASTA_PROJETO / "02_mercado"

# Cache e arquivos intermediários
PASTA_CACHE = PASTA_SAIDA

# Criação automática da pasta
PASTA_SAIDA.mkdir(parents=True, exist_ok=True)

# PDF BCA de entrada
PDF_BCA = BASE_DIR / "BCA_2026.pdf"

API_KEY = os.getenv("GEMINI_API_KEY")
MODELO_GEMINI = os.getenv("GEMINI_MODEL", "gemma-4-31b-it")

TIMEOUT_MS = 600_000
MAX_TENTATIVAS = 10

# Controle local de geração Gemini.
MIN_INTERVALO_CHAMADAS_SEGUNDOS = 30
MAX_CHAMADAS_POR_MINUTO = 1
LIMITE_TOKENS_POR_MINUTO = 14_000
JANELA_SEGUNDOS = 60
MARGEM_CONTAGEM_TOKENS = 1.10

# Quantas páginas candidatas vão em cada PDF temporário.
PAGINAS_POR_LOTE = 8

# "todas" = catálogo completo; "jatos" = apenas jatos executivos.
ESCOPO_AERONAVES = "todas"
VERSAO_EXTRACAO = "2026-11-06-deterministico-v1"
VERSAO_EXTRACAO_MODELO = "2026-11-06-modelo-v4"  # cache próprio do modo LLM

# Consolidação final: quantidade inicial de aeronaves por grupo.
# O agente reduz automaticamente o grupo se a contagem de tokens ficar alta.
CANDIDATOS_POR_LOTE_CONSOLIDACAO = 4

# Termos usados apenas para localizar páginas candidatas no texto do PDF.
# As páginas vizinhas também são incluídas para não cortar tabelas entre páginas.
TERMOS_BCA = (
    "nbaa ifr",
    "takeoff field length",
    "take-off field length",
    "tofl",
    "equipped price",
    "business jet",
    "business jets",
    "executive jet",
    "executive jets",
    "jet aircraft",
    "aircraft comparison",
)

# Dois modos de extração do BCA (escolhido por input no início; --modo/BCA_MODO pulam a pergunta):
#   python : determinístico (seção 5A), sem Gemini.
#   modelo : Gemini em lotes. Só neste modo (e nas análises LLM) o cliente é necessário.
client = None
if API_KEY and genai is not None:
    client = genai.Client(
        api_key=API_KEY,
        http_options=types.HttpOptions(timeout=TIMEOUT_MS),
    )


# =============================================================================
# 2. CONTROLE DE CHAMADAS E TOKENS
# =============================================================================

# Cada registro: (instante_monotônico, tokens_estimados).
HISTORICO_GEMINI: deque[tuple[float, int]] = deque()
ULTIMA_CHAMADA_GERACAO: Optional[float] = None
LOCK_GEMINI = Lock()


def _limpar_historico_agora(agora: float) -> None:
    while HISTORICO_GEMINI and agora - HISTORICO_GEMINI[0][0] >= JANELA_SEGUNDOS:
        HISTORICO_GEMINI.popleft()


def contar_tokens_entrada(conteudos) -> int:
    """Conta os tokens de entrada antes de cada tentativa de geração."""
    resposta = client.models.count_tokens(
        model=MODELO_GEMINI,
        contents=conteudos,
    )
    total = getattr(resposta, "total_tokens", None)
    if total is None:
        raise RuntimeError("A API não retornou total_tokens na contagem.")
    estimado = int(total * MARGEM_CONTAGEM_TOKENS)
    log_api(f"Tokens de entrada: {total:,}")
    if estimado > LIMITE_TOKENS_POR_MINUTO:
        raise RuntimeError(
            f"Esta solicitação exige aproximadamente {estimado:,} tokens, "
            f"acima do limite local de {LIMITE_TOKENS_POR_MINUTO:,}. "
            "Reduza o lote de páginas ou divida a análise."
        )
    return estimado


def aguardar_e_registrar_chamada(tokens_estimados: int) -> None:
    """
    Aplica intervalo mínimo, limite de chamadas/minuto e limite de tokens/minuto.
    A reserva é registrada antes da chamada, inclusive se a geração falhar.
    """
    global ULTIMA_CHAMADA_GERACAO

    while True:
        with LOCK_GEMINI:
            agora = time.monotonic()
            _limpar_historico_agora(agora)

            esperas = []

            if ULTIMA_CHAMADA_GERACAO is not None:
                decorrido = agora - ULTIMA_CHAMADA_GERACAO
                if decorrido < MIN_INTERVALO_CHAMADAS_SEGUNDOS:
                    esperas.append(MIN_INTERVALO_CHAMADAS_SEGUNDOS - decorrido)

            if len(HISTORICO_GEMINI) >= MAX_CHAMADAS_POR_MINUTO:
                tempo_liberacao = (
                    HISTORICO_GEMINI[0][0] + JANELA_SEGUNDOS - agora
                )
                if tempo_liberacao > 0:
                    esperas.append(tempo_liberacao)

            tokens_janela = sum(item[1] for item in HISTORICO_GEMINI)
            if tokens_janela + tokens_estimados > LIMITE_TOKENS_POR_MINUTO:
                if HISTORICO_GEMINI:
                    tempo_liberacao = (
                        HISTORICO_GEMINI[0][0] + JANELA_SEGUNDOS - agora
                    )
                    if tempo_liberacao > 0:
                        esperas.append(tempo_liberacao)
                else:
                    raise RuntimeError(
                        "A solicitação excede sozinha o limite local de tokens/minuto."
                    )

            espera = max(esperas, default=0.0)
            if espera <= 0:
                instante = time.monotonic()
                HISTORICO_GEMINI.append((instante, tokens_estimados))
                ULTIMA_CHAMADA_GERACAO = instante
                return

        log_api(f"Aguardando quota: {espera:.1f}s")
        time.sleep(espera + 0.2)


def extrair_tempo_retry(erro: Exception) -> Optional[float]:
    """Tenta obter retryDelay informado pela API do Google."""
    texto = str(erro)
    padroes = [
        r"retry in ([0-9.]+)s",
        r"retryDelay['\"]?\s*:\s*['\"]([0-9.]+)s",
        r"retry_delay['\"]?\s*:\s*['\"]?([0-9.]+)",
    ]
    for padrao in padroes:
        achado = re.search(padrao, texto, flags=re.I)
        if achado:
            try:
                return float(achado.group(1))
            except ValueError:
                pass
    return None


def erro_temporario(erro: Exception) -> bool:
    if isinstance(erro, (httpx.TimeoutException, httpx.TransportError)):
        return True
    texto = str(erro).lower()
    marcadores = (
        "429", "503", "504", "500", "502", "resource_exhausted",
        "unavailable", "deadline", "timeout", "temporarily",
        "internal server error", "rate limit", "quota",
    )
    return any(m in texto for m in marcadores)


def _extrair_json(texto: str):
    """Localiza um objeto JSON completo, sem alterar valores da resposta."""
    texto = texto.strip()
    texto = re.sub(r"^```(?:json)?\s*", "", texto, flags=re.I)
    texto = re.sub(r"\s*```$", "", texto)
    decoder = json.JSONDecoder()
    try:
        return json.loads(texto)
    except json.JSONDecodeError:
        pass
    for pos, char in enumerate(texto):
        if char != "{":
            continue
        try:
            objeto, _ = decoder.raw_decode(texto[pos:])
            if isinstance(objeto, dict):
                return objeto
        except json.JSONDecodeError:
            continue
    raise ValueError("A resposta não contém objeto JSON completo e válido.")


def _validar_resposta_gemma(resposta, schema):
    texto = (getattr(resposta, "text", None) or "").strip()
    if not texto:
        motivo = getattr(resposta, "prompt_feedback", None)
        candidatos = getattr(resposta, "candidates", None)
        raise ValueError(f"Resposta vazia do modelo. feedback={motivo}; candidates={candidatos}")
    return schema.model_validate(_extrair_json(texto))


def gerar_com_controle(
    conteudos,
    *,
    response_schema,
    descricao: str,
):
    """Chama Gemma sem response_schema e valida o JSON localmente."""
    ultimo_erro = None
    instrucao = (
        "Responda EXCLUSIVAMENTE com um único objeto JSON válido, sem markdown, "
        "sem texto antes/depois e sem comentários. Use exatamente estas chaves "
        "e tipos de dados definidos no esquema JSON a seguir. "
        "Para campos opcionais sem evidência, use null; para listas use []. "
        "Não invente informações.\nESQUEMA JSON:\n"
        + json.dumps(response_schema.model_json_schema(), ensure_ascii=False)
    )
    conteudos_atuais = list(conteudos) + [instrucao]

    for tentativa in range(1, MAX_TENTATIVAS + 1):
        log_api(f"{descricao} - tentativa {tentativa}/{MAX_TENTATIVAS}")
        tokens = contar_tokens_entrada(conteudos_atuais)
        aguardar_e_registrar_chamada(tokens)
        try:
            resposta = client.models.generate_content(
                model=MODELO_GEMINI,
                contents=conteudos_atuais,
                config=types.GenerateContentConfig(temperature=0.1),
            )
            return _validar_resposta_gemma(resposta, response_schema)
        except Exception as exc:
            ultimo_erro = exc
            if isinstance(exc, httpx.TimeoutException):
                log_aviso(f"Timeout de rede/API ({type(exc).__name__})")
            codigo = getattr(exc, "code", None)
            if codigo == 400 or "400 INVALID_ARGUMENT" in str(exc):
                raise RuntimeError(
                    "A API rejeitou a requisição com HTTP 400 mesmo sem "
                    "response_schema. Verifique suporte do modelo ao PDF enviado "
                    "e o nome real em GEMINI_MODEL. Erro original: " + str(exc)
                ) from exc
            if isinstance(exc, (ValidationError, ValueError)):
                log_aviso(f"Resposta fora do formato: {str(exc)[:200]}")
                if tentativa >= MAX_TENTATIVAS:
                    raise RuntimeError(
                        "O modelo não conseguiu devolver JSON válido após "
                        f"{MAX_TENTATIVAS} tentativas: {exc}"
                    ) from exc
                # Não substitui valores ou fabrica campos; pede nova geração.
                conteudos_atuais = list(conteudos) + [
                    instrucao,
                    "A resposta anterior não passou na validação JSON/Pydantic. "
                    "Gere novamente o objeto completo, com os tipos exigidos."
                ]
            elif not erro_temporario(exc) or tentativa >= MAX_TENTATIVAS:
                raise
            retry_api = extrair_tempo_retry(exc)
            espera_backoff = min(10 * (2 ** (tentativa - 1)), 120)
            espera = max(retry_api or 0, espera_backoff) + random.uniform(1, 3)
            log_info(f"Nova tentativa em {espera:.0f}s")
            time.sleep(espera)
    raise RuntimeError(f"Falha após {MAX_TENTATIVAS} tentativas: {ultimo_erro}")


# =============================================================================
# 3. SCHEMAS
# =============================================================================

class Evidencia(BaseModel):
    campo: str = "Não informado"
    trecho_original: str = ""
    tipo_informacao: str = "Não informado"
    interpretacao: str = ""


class PerfilVendedor(BaseModel):
    origem: Optional[str] = "Não informado"
    destino: Optional[str] = "Não informado"
    aeroportos_especificos: list[str] = Field(default_factory=list)
    numero_passageiros: Optional[int] = None
    tripulacao: Optional[str] = "Não informado"
    bagagem: Optional[str] = "Não informado"
    distancia_milhas_nauticas: Optional[float] = None
    comprimento_pista_pes: Optional[float] = None
    orcamento_aquisicao: Optional[str] = "Não informado"
    voo_sem_escala: Optional[bool] = None
    objetivo_missao: Optional[str] = "Não informado"
    necessidades_operacionais: list[str] = Field(default_factory=list)
    preferencias_cliente: list[str] = Field(default_factory=list)
    informacoes_nao_informadas: list[str] = Field(default_factory=list)
    contradicoes: list[str] = Field(default_factory=list)
    evidencias: list[Evidencia] = Field(default_factory=list)


class DocumentoVendedor(BaseModel):
    cliente_numero: Optional[int] = None
    perfil: PerfilVendedor
    avisos_validacao: list[str] = Field(default_factory=list)


class AeronaveBCA(BaseModel):
    fabricante: Optional[str] = None
    modelo: str
    categoria_bca: Optional[str] = None
    preco_usd: Optional[float] = None
    assentos_passageiros_max: Optional[int] = None
    nbaa_ifr_range_nm: Optional[float] = None
    tofl_sl_isa_ft: Optional[float] = None
    tofl_5000ft_25c_ft: Optional[float] = None
    pagina_bca: Optional[str] = None
    evidencia_linha: Optional[str] = None
    observacoes_extracao: list[str] = Field(default_factory=list)
    # Campos adicionados pelo extrator determinístico (todos opcionais):
    modelo_linhas: list[str] = Field(default_factory=list)
    tipo: Optional[str] = None
    preco_marcador: Optional[str] = None
    assentos_raw: Optional[str] = None
    tripulacao: Optional[int] = None
    nbaa_ifr_range_fonte: Optional[str] = None
    rotulo_tofl: Optional[str] = None
    max_takeoff_lb: Optional[float] = None
    mission_weight_lb: Optional[float] = None
    landing_distance_ft: Optional[float] = None
    pagina_fisica_pdf: Optional[int] = None


class ExtracaoBCA(BaseModel):
    edicao_identificada: Optional[str] = None
    paginas_tabelas_identificadas: list[str] = Field(default_factory=list)
    aeronaves: list[AeronaveBCA] = Field(default_factory=list)
    avisos: list[str] = Field(default_factory=list)
    assinatura_pdf: Optional[str] = None
    escopo_extracao: Optional[str] = None
    versao_extracao: Optional[str] = None


class AnaliseEspecializada(BaseModel):
    area: str
    conclusoes: list[str] = Field(default_factory=list)
    candidatos_relevantes: list[str] = Field(default_factory=list)
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


class AnaliseGemini(BaseModel):
    resumo_executivo: str
    melhor_candidato_preliminar: str = "Nenhum identificado"
    justificativa: str
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


class ResumoConsolidacaoLote(BaseModel):
    lote: str
    resumo: str
    melhor_candidato_deste_lote: str = "Nenhum identificado"
    candidatos_considerados: list[str] = Field(default_factory=list)
    justificativas: list[str] = Field(default_factory=list)
    riscos_tecnicos: list[str] = Field(default_factory=list)
    dados_a_confirmar: list[str] = Field(default_factory=list)
    ressalvas: list[str] = Field(default_factory=list)


# =============================================================================
# 4. LEITURA DO JSON DO AGENTE VENDEDOR
# =============================================================================

def carregar_json_vendedor(caminho: Path) -> DocumentoVendedor:
    if not caminho.is_file():
        raise FileNotFoundError(f"JSON do Agente Vendedor não encontrado: {caminho}")

    with caminho.open("r", encoding="utf-8") as arquivo:
        bruto = json.load(arquivo)

    if not isinstance(bruto, dict):
        raise ValueError("O JSON do vendedor precisa conter um objeto.")

    if "perfil" not in bruto:
        bruto = {
            "cliente_numero": bruto.get("cliente_numero"),
            "perfil": bruto,
        }

    try:
        return DocumentoVendedor.model_validate(bruto)
    except ValidationError as exc:
        raise ValueError(f"JSON do vendedor incompatível com o schema:\n{exc}") from exc


# =============================================================================
# 5. IDENTIFICAÇÃO DAS PÁGINAS E EXTRAÇÃO DO BCA EM LOTES
# =============================================================================

def validar_pdf(caminho: Path) -> dict:
    if not caminho.is_file():
        raise FileNotFoundError(
            f"Não encontrei {caminho.name}. Coloque o PDF na pasta do agente."
        )

    leitor = PdfReader(str(caminho))
    if leitor.is_encrypted:
        raise ValueError("O PDF está protegido por senha.")
    if not leitor.pages:
        raise ValueError("O PDF não contém páginas.")

    paginas_com_texto = sum(
        bool((pagina.extract_text() or "").strip())
        for pagina in leitor.pages
    )
    if paginas_com_texto == 0:
        raise ValueError(
            "Não foi possível extrair texto do PDF. Ele pode ser digitalizado "
            "como imagem; será necessário OCR."
        )

    return {
        "arquivo": caminho.name,
        "paginas_pdf": len(leitor.pages),
        "paginas_com_texto": paginas_com_texto,
        "tamanho_bytes": caminho.stat().st_size,
    }


# =============================================================================
# 5A. EXTRATOR BCA DETERMINÍSTICO (PDF -> JSON por coordenadas, sem LLM)
# =============================================================================
# Cada campo é buscado pelo RÓTULO EXATO da linha (regex ancorada no fim), então
# não há como trocar 'Mission Weight' por 'NBAA IFR Range'. Dependência: pdfplumber.

# --------------------------------------------------------------------------
# Campos buscados: nome_interno -> regex aplicada ao FINAL do rótulo da linha.
# (rótulo normalizado: minúsculas, espaços colapsados)
# --------------------------------------------------------------------------
BCA_CAMPOS = {
    "preco": r"bca equipped price",
    "seating": r"seating",
    "nbaa_ifr_range": r"nbaa ifr range",
    "mission_weight": r"mission weight",
    "tofl_sl": r"(?:tofl|to) \(sl elev\./isa temp\.\)",
    "tofl_5000": r"(?:tofl|to) \(5,000-ft\. elev\.@25c\)",
    "mtow": r"max takeoff",
    "landing_distance": r"landing distance",
}
BCA_CAMPOS_RE = {k: re.compile(v + r"$") for k, v in BCA_CAMPOS.items()}
BCA_RE_NM = re.compile(r"nautical miles$")


# --------------------------------------------------------------------------
# Utilidades
# --------------------------------------------------------------------------
def _bca_norm(txt: str) -> str:
    return re.sub(r"\s+", " ", txt).strip().lower()


def _bca_parse_num(bruto: str | None) -> float | None:
    """'$1,404,000*' -> 1404000.0 ; '14,500p' -> 14500.0 ; 'NA' -> None."""
    if bruto is None:
        return None
    m = re.match(r"^\$?\s*(\d[\d,]*(?:\.\d+)?)", bruto.strip())
    if not m:
        return None
    return float(m.group(1).replace(",", ""))


def _bca_parse_seating(bruto: str | None) -> tuple[int | None, int | None]:
    """'2+9/11/19' -> (tripulação=2, máx. passageiros=19); '4+19/NA/195***' -> (4, 195)."""
    if not bruto:
        return None, None
    m = re.match(r"^(\d+)\+(.+)$", bruto.strip())
    if not m:
        return None, None
    partes = [re.sub(r"[^\dA-Za-z]", "", p) for p in m.group(2).split("/")]
    nums = [int(p) for p in partes if p.isdigit()]
    return int(m.group(1)), (nums[-1] if nums else None)


def _bca_tipo_categoria(titulo: str) -> str:
    t = titulo.upper()
    if "PISTON" in t:
        return "piston"
    if "TURBOPROP" in t:
        return "turboprop_mono" if t.startswith("SINGLE") else "turboprop_multi"
    if "JET" in t:
        return "jato"
    return "desconhecido"


def _bca_frases(pagina) -> list[dict]:
    """Frases (palavras + espaços reais do PDF) com coordenadas."""
    out = []
    for w in pagina.extract_words(x_tolerance=2, y_tolerance=2, keep_blank_chars=True):
        t = w["text"].strip()
        if t:
            out.append({"t": t, "x0": w["x0"], "x1": w["x1"], "top": w["top"],
                        "cx": (w["x0"] + w["x1"]) / 2})
    return out


def _bca_agrupar_linhas(fs: list[dict], tol: float = 2.6) -> list[list[dict]]:
    linhas: list[list[dict]] = []
    for f in sorted(fs, key=lambda f: (f["top"], f["x0"])):
        if linhas and f["top"] - linhas[-1][-1]["top"] <= tol:
            linhas[-1].append(f)
        else:
            linhas.append([f])
    return linhas


# --------------------------------------------------------------------------
# Extração de uma tabela
# --------------------------------------------------------------------------
def _bca_extrair_tabela(fs_tabela: list[dict], titulo: str, avisos: list[str]) -> list[dict]:
    manuf = [f for f in fs_tabela if f["t"] == "Manufacturer"]
    modelo_lab = [f for f in fs_tabela if f["t"] == "Model"]
    preco_lab = next((f for f in fs_tabela if f["t"].startswith("BCA Equipped")), None)
    if not manuf or preco_lab is None:
        return []
    y_manuf = manuf[0]["top"]
    y_model = modelo_lab[0]["top"] if modelo_lab else y_manuf + 10

    # --- colunas: centros X dos preços -----------------------------------
    precos = [f for f in fs_tabela
              if abs(f["top"] - preco_lab["top"]) <= 4 and f["t"].startswith("$")]
    precos.sort(key=lambda f: f["cx"])
    if not precos:
        avisos.append(f"[{titulo}] linha de preço sem valores.")
        return []
    centros = [p["cx"] for p in precos]
    corte_dados = centros[0] - 20  # tudo à esquerda disso é rótulo

    def coluna(cx: float) -> int:
        return min(range(len(centros)), key=lambda i: abs(centros[i] - cx))

    # --- cabeçalho: fabricante x modelo ------------------------------------
    limite_hdr = (y_manuf + y_model) / 2
    hdr = [f for f in fs_tabela
           if y_manuf - 2 <= f["top"] < preco_lab["top"] - 1 and f["cx"] >= corte_dados]
    cab = [{"fab": [], "mod": []} for _ in centros]
    for f in sorted(hdr, key=lambda f: (f["top"], f["x0"])):
        (cab[coluna(f["cx"])]["fab"] if f["top"] < limite_hdr
         else cab[coluna(f["cx"])]["mod"]).append(f["t"])

    # --- linhas de dados ---------------------------------------------------
    corpo = [f for f in fs_tabela if f["top"] >= preco_lab["top"] - 3]
    linhas = []
    for grupo in _bca_agrupar_linhas(corpo):
        rotulo = _bca_norm(" ".join(f["t"] for f in sorted(grupo, key=lambda f: f["x0"])
                               if f["cx"] < corte_dados))
        valores: dict[int, str] = {}
        for f in sorted(grupo, key=lambda f: f["x0"]):
            if f["cx"] >= corte_dados:
                i = coluna(f["cx"])
                valores[i] = (valores.get(i, "") + " " + f["t"]).strip()
        linhas.append({"rotulo": rotulo, "valores": valores,
                       "top": min(f["top"] for f in grupo)})

    # --- campos por rótulo exato (primeira ocorrência) -----------------------
    achados: dict[str, dict] = {}
    for campo, rx in BCA_CAMPOS_RE.items():
        cands = [l for l in linhas if rx.search(l["rotulo"]) and l["valores"]]
        if len(cands) > 1 and campo != "preco":
            avisos.append(f"[{titulo}] rótulo '{campo}' apareceu {len(cands)}x; usei a 1ª.")
        if cands:
            achados[campo] = cands[0]
    nm_rows = [l for l in linhas if BCA_RE_NM.search(l["rotulo"]) and l["valores"]]

    tipo = _bca_tipo_categoria(titulo)
    aeronaves = []
    for i in range(len(centros)):
        def bruto(campo: str) -> str | None:
            l = achados.get(campo)
            return l["valores"].get(i) if l else None

        # NBAA IFR Range: linha explícita; senão, regra documentada p/ turboélices.
        fonte_nbaa, bruto_nbaa = None, None
        if tipo == "piston":
            fonte_nbaa = "não se aplica a pistões (BCA não publica NBAA IFR Range)"
        elif "nbaa_ifr_range" in achados:
            bruto_nbaa = bruto("nbaa_ifr_range")
            fonte_nbaa = "linha 'NBAA IFR Range' (Airport Performance)"
        elif tipo == "turboprop_mono" and len(nm_rows) == 2:
            bruto_nbaa = nm_rows[0]["valores"].get(i)
            fonte_nbaa = ("sem linha 'NBAA IFR Range'; usado 'Full Fuel (w/available "
                          "payload) > Nautical Miles'")
        elif tipo == "turboprop_multi" and len(nm_rows) == 4:
            bruto_nbaa = nm_rows[1]["valores"].get(i)
            fonte_nbaa = ("sem linha 'NBAA IFR Range'; usado 'Max Fuel (w/available "
                          "payload) > Nautical Miles'")
        else:
            avisos.append(f"[{titulo}] estrutura de alcance inesperada "
                          f"({len(nm_rows)} linhas 'Nautical Miles'); NBAA = null.")

        raw = {
            "preco": bruto("preco"), "seating": bruto("seating"),
            "nbaa": bruto_nbaa, "mission_weight": bruto("mission_weight"),
            "tofl_sl": bruto("tofl_sl"), "tofl_5000": bruto("tofl_5000"),
            "mtow": bruto("mtow"), "landing": bruto("landing_distance"),
        }
        tripulacao, pax_max = _bca_parse_seating(raw["seating"])
        modelo_linhas = cab[i]["mod"]
        aeronaves.append({
            "fabricante": " ".join(cab[i]["fab"]) or None,
            "modelo": " ".join(modelo_linhas) or None,
            "modelo_linhas": modelo_linhas,
            "categoria_bca": titulo,
            "tipo": tipo,
            "preco_usd": _bca_parse_num(raw["preco"]),
            "preco_marcador": (re.search(r"\*+$", raw["preco"]).group(0)
                               if raw["preco"] and re.search(r"\*+$", raw["preco"]) else None),
            "assentos_raw": raw["seating"],
            "tripulacao": tripulacao,
            "assentos_passageiros_max": pax_max,
            "nbaa_ifr_range_nm": _bca_parse_num(raw["nbaa"]),
            "nbaa_ifr_range_fonte": fonte_nbaa,
            "tofl_sl_isa_ft": _bca_parse_num(raw["tofl_sl"]),
            "tofl_5000ft_25c_ft": _bca_parse_num(raw["tofl_5000"]),
            "rotulo_tofl": (achados["tofl_sl"]["rotulo"].split("(")[0].split()[-1].upper()
                            if "tofl_sl" in achados else None),
            "max_takeoff_lb": _bca_parse_num(raw["mtow"]),
            "mission_weight_lb": _bca_parse_num(raw["mission_weight"]),
            "landing_distance_ft": _bca_parse_num(raw["landing"]),
            "_raw": raw,
        })
    return aeronaves


# --------------------------------------------------------------------------
# Validações cruzadas
# --------------------------------------------------------------------------
def validar_aeronave_bca(a: dict) -> list[str]:
    obs: list[str] = []
    nome = a["modelo"] or "?"
    if not a["fabricante"] or not a["modelo"]:
        obs.append("fabricante/modelo vazio: conferir cabeçalho.")
    if not a["preco_usd"] or a["preco_usd"] <= 0:
        obs.append("preço ausente.")
    nbaa, mw, mtow = a["nbaa_ifr_range_nm"], a["mission_weight_lb"], a["max_takeoff_lb"]
    if nbaa is not None:
        if nbaa > 9_500:
            obs.append(f"NBAA IFR Range={nbaa:,.0f} NM é implausível (parece um peso).")
        if mw is not None and nbaa == mw:
            obs.append("NBAA IFR Range idêntico ao Mission Weight: possível troca de linha.")
    if mw is not None and mtow is not None and mw > mtow * 1.005:
        obs.append(f"Mission Weight ({mw:,.0f}) > MTOW ({mtow:,.0f}).")
    t0, t5 = a["tofl_sl_isa_ft"], a["tofl_5000ft_25c_ft"]
    if t0 and t5 and t5 < t0:
        obs.append(f"TOFL a 5.000 ft ({t5:,.0f}) < TOFL ao nível do mar ({t0:,.0f}): "
                   "incoerente fisicamente; provável erro impresso na fonte (BCA).")
    if a["preco_marcador"]:
        obs.append(f"Preço com marcador '{a['preco_marcador']}' (ver nota de rodapé do BCA: "
                   "normalmente estimativa BCA).")
    if a["tipo"] != "piston" and a["nbaa_ifr_range_nm"] is None:
        obs.append("NBAA IFR Range ausente/NA na fonte.")
    if a["rotulo_tofl"] == "TO":
        obs.append("Fonte rotula 'TO' (takeoff), não 'TOFL'; usado como equivalente.")
    return obs


# --------------------------------------------------------------------------
# Pipeline do PDF
# --------------------------------------------------------------------------
def extrair_tabelas_bca_pdf(caminho: Path) -> dict:
    avisos: list[str] = []
    aeronaves: list[dict] = []
    paginas_impressas: list[str] = []
    edicao = None
    ultimo_titulo = ""

    with pdfplumber.open(str(caminho)) as pdf:
        for idx, pg in enumerate(pdf.pages, start=1):
            texto = pg.extract_text() or ""
            m = re.search(r"HANDBOOK\s+(Q\d)\s+(\d{4})\s+(\d{1,3})\b", texto) or \
                re.search(r"\b(\d{1,3})\s+PURCHASE PLANNING HANDBOOK\s+(Q\d)\s+(\d{4})", texto)
            pag_imp = None
            if m:
                g = m.groups()
                if g[0].startswith("Q"):
                    edicao, pag_imp = f"{g[0]} {g[1]}", g[2]
                else:
                    edicao, pag_imp = f"{g[1]} {g[2]}", g[0]
            if pag_imp:
                paginas_impressas.append(pag_imp)

            fs = _bca_frases(pg)
            labels = sorted([f for f in fs if f["t"] == "Manufacturer"], key=lambda f: f["x0"])
            if not labels:
                avisos.append(f"Página física {idx}: nenhuma tabela ('Manufacturer' não achado).")
                continue
            for k, lab in enumerate(labels):
                x_ini = lab["x0"] - 8
                x_fim = labels[k + 1]["x0"] - 8 if k + 1 < len(labels) else pg.width
                fs_t = [f for f in fs if x_ini <= f["x0"] < x_fim and f["top"] >= 38]
                tit = " ".join(f["t"] for f in sorted(fs_t, key=lambda f: f["x0"])
                               if 38 <= f["top"] <= 55)
                tit = tit if tit else ultimo_titulo
                ultimo_titulo = tit
                for a in _bca_extrair_tabela(fs_t, tit, avisos):
                    a["pagina_bca"] = pag_imp
                    a["pagina_fisica_pdf"] = idx
                    aeronaves.append(a)

    for a in aeronaves:
        raw = a.pop("_raw")
        partes = [a["modelo"], raw["preco"], raw["seating"] and f"Seating {raw['seating']}",
                  raw["nbaa"] and f"NBAA {raw['nbaa']}",
                  raw["mission_weight"] and f"Mission Weight {raw['mission_weight']}",
                  raw["tofl_sl"] and f"TOFL SL {raw['tofl_sl']}",
                  raw["tofl_5000"] and f"TOFL 5000ft {raw['tofl_5000']}"]
        a["evidencia_linha"] = " | ".join(p for p in partes if p)
        a["observacoes_extracao"] = validar_aeronave_bca(a)

    return {
        "edicao_identificada": edicao,
        "paginas_tabelas_identificadas": list(dict.fromkeys(paginas_impressas)),
        "aeronaves": aeronaves,
        "avisos": avisos,
        "assinatura_pdf": hashlib.sha256(caminho.read_bytes()).hexdigest(),
        "escopo_extracao": ESCOPO_AERONAVES,
        "versao_extracao": VERSAO_EXTRACAO,
    }



def _exigir_cliente() -> None:
    if client is None:
        raise EnvironmentError(
            "Modo 'modelo' exige GEMINI_API_KEY e o SDK google-genai "
            "(pip install google-genai). Use --modo python para extrair sem LLM."
        )


PROMPT_EXTRACAO_BCA = """
Você é um extrator de dados técnicos de tabelas do Business & Commercial Aviation (BCA).

Analise exclusivamente o PDF/lote de páginas anexado. Extraia TODAS as aeronaves
que ocupam colunas próprias nas tabelas comparativas deste lote, incluindo
pistão, turboélices e jatos executivos. Preserve modelos e variantes distintos.
Não inclua aeronaves que não estejam efetivamente nas tabelas anexadas.

Para cada aeronave, extraia apenas os campos claramente publicados:
- fabricante;
- modelo;
- categoria BCA, se identificável;
- preço equipado em USD;
- maior configuração de assentos de passageiros indicada;
- NBAA IFR Range em milhas náuticas (NM);
- TOFL/Takeoff Field Length ao nível do mar/ISA em pés;
- TOFL a 5.000 ft / 25°C em pés, se existir;
- página impressa do BCA, apenas quando visível;
- transcrição curta da linha/tabela que sustenta a extração.

REGRAS:
1. Não invente, estime, complete nem use conhecimento externo.
2. Não confunda alcance com velocidade, combustível ou outra coluna.
3. Não confunda preço base com preço equipado.
4. Converta números para valores numéricos sem separador de milhar.
5. Campo ausente/ilegível deve ser null, com explicação em observacoes_extracao ou avisos.
6. Não descarte aeronaves por falta de algum campo.
7. Não crie duplicatas; preserve modelos distintos.
8. Não deduza página impressa pelo índice físico do PDF.
9. Se não houver tabela de aeronaves neste lote, retorne aeronaves=[] e explique apenas
   se houver alguma dificuldade real de leitura.
10. Não retorne modelos que não estejam visíveis no lote.
11. Preserve o fabricante e o nome do modelo como aparecem na fonte.
12. Cada coluna de modelo é um registro; não resuma nem omita colunas.
13. Para pistões, o campo NBAA IFR Range pode ser null; não use alcance de outro regime.
14. TOFL pode ter outro nome na tabela; só preencha se a métrica corresponder exatamente.

Responda no schema JSON solicitado. A edição só deve ser informada se estiver
identificável no conteúdo enviado.
""".strip()


def localizar_paginas_candidatas(caminho_pdf: Path) -> tuple[list[int], dict]:
    """
    Procura termos típicos das tabelas no texto extraído do PDF.
    Retorna índices físicos (base zero), incluindo uma página vizinha de cada lado.
    Se a busca textual não localizar termos, usa todas as páginas para não omitir
    silenciosamente conteúdo.
    """
    leitor = PdfReader(str(caminho_pdf))
    paginas_base = []

    for indice, pagina in enumerate(leitor.pages):
        texto = (pagina.extract_text() or "").lower()
        if any(termo in texto for termo in TERMOS_BCA):
            paginas_base.append(indice)

    if not paginas_base:
        paginas = list(range(len(leitor.pages)))
        metodo = "fallback_todas_as_paginas_sem_palavras_chave"
    else:
        conjunto = set()
        for indice in paginas_base:
            conjunto.add(indice)
            if indice > 0:
                conjunto.add(indice - 1)
            if indice + 1 < len(leitor.pages):
                conjunto.add(indice + 1)
        paginas = sorted(conjunto)
        metodo = "palavras_chave_com_paginas_vizinhas"

    return paginas, {
        "metodo_selecao_paginas": metodo,
        "paginas_fisicas_candidatas": [i + 1 for i in paginas],
        "total_paginas_candidatas": len(paginas),
        "termos_busca": list(TERMOS_BCA),
    }


def criar_pdf_lote(caminho_original: Path, indices_paginas: list[int], destino: Path) -> None:
    leitor = PdfReader(str(caminho_original))
    escritor = PdfWriter()
    for indice in indices_paginas:
        escritor.add_page(leitor.pages[indice])
    with destino.open("wb") as arquivo:
        escritor.write(arquivo)


def deduplicar_aeronaves(aeronaves: list[AeronaveBCA]) -> list[AeronaveBCA]:
    unicas: dict[tuple[str, str], AeronaveBCA] = {}
    for aeronave in aeronaves:
        chave = (
            (aeronave.fabricante or "").strip().casefold(),
            aeronave.modelo.strip().casefold(),
        )
        if chave not in unicas:
            unicas[chave] = aeronave
            continue

        # Complementa campos nulos com dados encontrados em outro lote.
        existente = unicas[chave]
        dados = existente.model_dump()
        novos = aeronave.model_dump()
        for campo, valor in novos.items():
            if campo == "observacoes_extracao":
                dados[campo] = list(dict.fromkeys((dados[campo] or []) + (valor or [])))
            elif dados.get(campo) in (None, "", []):
                dados[campo] = valor
        unicas[chave] = AeronaveBCA.model_validate(dados)

    return list(unicas.values())


def extrair_bca_modelo(
    caminho_pdf: Path,
    usar_cache: bool = True,
) -> tuple[ExtracaoBCA, dict]:
    PASTA_CACHE.mkdir(parents=True, exist_ok=True)
    cache = PASTA_CACHE / f"{caminho_pdf.stem}_aeronaves_extraidas_modelo.json"

    assinatura = hashlib.sha256(caminho_pdf.read_bytes()).hexdigest()

    if usar_cache and cache.is_file():
        try:
            dados = json.loads(cache.read_text(encoding="utf-8"))
            extracao = ExtracaoBCA.model_validate(dados)
            if (extracao.aeronaves
                and extracao.assinatura_pdf == assinatura
                and extracao.escopo_extracao == ESCOPO_AERONAVES
                and extracao.versao_extracao == VERSAO_EXTRACAO_MODELO):
                log_cache(f"BCA validado e reutilizado: {cache.name}")
                return extracao, {
                    "metodo": "cache_json_validado",
                    "cache": cache.name,
                    "total_lotes_processados": 0,
                }
            log_aviso("Cache incompatível com PDF/escopo/versão; reextraindo")
        except Exception as exc:
            log_aviso(f"Cache inválido ({exc}); reextraindo")

    _exigir_cliente()
    paginas, info_selecao = localizar_paginas_candidatas(caminho_pdf)
    lotes = [
        paginas[i:i + PAGINAS_POR_LOTE]
        for i in range(0, len(paginas), PAGINAS_POR_LOTE)
    ]

    log_info(f"Páginas candidatas: {len(paginas)} em {len(lotes)} lote(s)")

    # Cache incremental: cada lote concluído é preservado após falhas de rede.
    pasta_lotes = PASTA_CACHE / f"{caminho_pdf.stem}_lotes"
    pasta_lotes.mkdir(parents=True, exist_ok=True)
    chave_execucao = hashlib.sha256(
        f"{assinatura}|{VERSAO_EXTRACAO_MODELO}|{ESCOPO_AERONAVES}|{MODELO_GEMINI}".encode()
    ).hexdigest()[:16]

    todas_aeronaves: list[AeronaveBCA] = []
    edicoes = []
    paginas_identificadas = []
    avisos = []

    with tempfile.TemporaryDirectory(prefix="bca_lotes_") as pasta_temp:
        pasta_temp_path = Path(pasta_temp)

        for numero_lote, indices in enumerate(lotes, start=1):
            log_sub(
                f"Lote {numero_lote}/{len(lotes)} - "
                f"páginas {', '.join(str(i + 1) for i in indices)}"
            )

            cache_lote = pasta_lotes / f"{chave_execucao}_lote_{numero_lote:03d}.json"
            if cache_lote.is_file():
                try:
                    extraido = ExtracaoBCA.model_validate_json(cache_lote.read_text(encoding="utf-8"))
                    todas_aeronaves.extend(extraido.aeronaves)
                    if extraido.edicao_identificada:
                        edicoes.append(extraido.edicao_identificada)
                    paginas_identificadas.extend(extraido.paginas_tabelas_identificadas)
                    avisos.extend(extraido.avisos)
                    log_cache(f"Lote recuperado: {len(extraido.aeronaves)} aeronaves")
                    continue
                except (ValueError, ValidationError) as exc:
                    log_aviso(f"Cache de lote inválido ({exc}); reprocessando")

            pdf_lote = pasta_temp_path / f"bca_lote_{numero_lote:03d}.pdf"
            criar_pdf_lote(caminho_pdf, indices, pdf_lote)

            arquivo_remoto = None
            try:
                arquivo_remoto = client.files.upload(
                    file=str(pdf_lote),
                    config={"mime_type": "application/pdf"},
                )

                prompt_lote = (
                    PROMPT_EXTRACAO_BCA
                    + "\n\nPáginas físicas deste lote no PDF original (base 1): "
                    + ", ".join(str(i + 1) for i in indices)
                    + ". Use somente as páginas efetivamente visíveis no arquivo."
                    + ("\nESCOPO: extraia APENAS jatos executivos." if ESCOPO_AERONAVES == "jatos" else "\nESCOPO: extraia TODAS as categorias de aeronaves.")
                )

                extraido = gerar_com_controle(
                    [arquivo_remoto, prompt_lote],
                    response_schema=ExtracaoBCA,
                    descricao=f"extração BCA lote {numero_lote}/{len(lotes)}",
                )

                cache_lote.write_text(
                    extraido.model_dump_json(indent=2), encoding="utf-8"
                )
                todas_aeronaves.extend(extraido.aeronaves)
                if extraido.edicao_identificada:
                    edicoes.append(extraido.edicao_identificada)
                paginas_identificadas.extend(extraido.paginas_tabelas_identificadas)
                avisos.extend(extraido.avisos)

                log_ok(f"{len(extraido.aeronaves)} aeronaves identificadas")

            finally:
                if arquivo_remoto is not None:
                    try:
                        client.files.delete(name=arquivo_remoto.name)
                    except Exception as exc:
                        log_aviso(f"Não foi possível excluir o arquivo remoto: {exc}")

    aeronaves_unicas = deduplicar_aeronaves(todas_aeronaves)
    for _a in aeronaves_unicas:  # checagens por regras sobre o que o modelo devolveu
        _a.tipo = _bca_tipo_categoria(_a.categoria_bca or "")
        for _obs in validar_aeronave_bca(_a.model_dump()):
            if _obs not in _a.observacoes_extracao:
                _a.observacoes_extracao.append(_obs)
    if not aeronaves_unicas:
        raise RuntimeError(
            "Nenhuma aeronave foi extraída. Confira o PDF, as páginas candidatas "
            "e a legibilidade das tabelas."
        )

    extracao_final = ExtracaoBCA(
        edicao_identificada=edicoes[0] if edicoes else None,
        paginas_tabelas_identificadas=list(dict.fromkeys(paginas_identificadas)),
        aeronaves=aeronaves_unicas,
        avisos=list(dict.fromkeys(avisos)),
        assinatura_pdf=assinatura,
        escopo_extracao=ESCOPO_AERONAVES,
        versao_extracao=VERSAO_EXTRACAO_MODELO,
    )

    cache.write_text(
        json.dumps(
            extracao_final.model_dump(mode="json"),
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    metodo = {
        "metodo": "extracao_pdf_gemini_em_lotes",
        "arquivo_pdf": caminho_pdf.name,
        "cache_criado": cache.name,
        "modelo_extracao": MODELO_GEMINI,
        "escopo_extracao": ESCOPO_AERONAVES,
        "assinatura_pdf": assinatura,
        "total_lotes_processados": len(lotes),
        **info_selecao,
    }
    return extracao_final, metodo


def extrair_bca_python(caminho_pdf: Path) -> tuple[ExtracaoBCA, dict]:
    """Modo PYTHON: extração determinística por coordenadas (seção 5A), sem LLM."""
    PASTA_CACHE.mkdir(parents=True, exist_ok=True)
    extracao = ExtracaoBCA.model_validate(extrair_tabelas_bca_pdf(caminho_pdf))
    if not extracao.aeronaves:
        raise RuntimeError("Nenhuma aeronave foi extraída. Confira o PDF.")

    cache = PASTA_CACHE / f"{caminho_pdf.stem}_aeronaves_extraidas.json"
    cache.write_text(
        json.dumps(extracao.model_dump(mode="json"), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return extracao, {
        "metodo": "extracao_deterministica_pdfplumber",
        "arquivo_pdf": caminho_pdf.name,
        "cache_criado": cache.name,
    }


def salvar_catalogo(extracao: ExtracaoBCA, caminho_pdf: Path) -> Path:
    PASTA_CACHE.mkdir(parents=True, exist_ok=True)
    destino = PASTA_CACHE / f"{caminho_pdf.stem}_aeronaves_extraidas.json"
    destino.write_text(
        json.dumps(extracao.model_dump(mode="json"), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return destino


def auditar_com_python(extracao: ExtracaoBCA, caminho_pdf: Path) -> int:
    """
    Modo 'modelo': confronta cada aeronave extraída pelo LLM com a leitura
    determinística do mesmo PDF e anota divergências em observacoes_extracao.
    Não altera valores; só sinaliza. Retorna o número de divergências.
    """
    try:
        ref = extrair_tabelas_bca_pdf(caminho_pdf)["aeronaves"]
    except Exception as exc:  # auditoria é opcional; nunca derruba a extração
        extracao.avisos.append(f"Auditoria Python indisponível: {exc}")
        return 0

    campos = ("nbaa_ifr_range_nm", "tofl_sl_isa_ft", "tofl_5000ft_25c_ft",
              "assentos_passageiros_max", "preco_usd")
    total = 0
    for a in extracao.aeronaves:
        preco = a.preco_usd or 0
        cands = [r for r in ref
                 if r["pagina_bca"] == a.pagina_bca and r["preco_usd"]
                 and abs(r["preco_usd"] - preco) <= max(preco, 1) * 0.01]
        if not cands:
            a.observacoes_extracao.append(
                "Auditoria Python: aeronave sem correspondente na leitura determinística.")
            total += 1
            continue
        r = min(cands, key=lambda r: abs(r["preco_usd"] - preco))
        for c in campos:
            vm, vp = getattr(a, c), r.get(c)
            if c == "preco_usd" and vm and vp and abs(vm - vp) <= vp * 0.005:
                continue
            if vm != vp:
                a.observacoes_extracao.append(
                    f"Divergência modelo x Python em {c}: modelo={vm} python={vp}")
                total += 1
    return total


def extrair_bca(caminho_pdf: Path, modo: str = "python") -> tuple[ExtracaoBCA, dict]:
    """Despachante. modo='python' (determinístico) ou 'modelo' (Gemini em lotes)."""
    if modo == "python":
        extracao, metodo = extrair_bca_python(caminho_pdf)
    elif modo == "modelo":
        extracao, metodo = extrair_bca_modelo(caminho_pdf)
        divergencias = auditar_com_python(extracao, caminho_pdf)
        metodo["divergencias_modelo_vs_python"] = divergencias
        log_info(f"Auditoria modelo x Python: {divergencias} divergência(s)")
    else:
        raise ValueError(f"Modo inválido: {modo!r}. Use 'python' ou 'modelo'.")
    salvar_catalogo(extracao, caminho_pdf)
    return extracao, metodo


def escolher_modo(argumento: Optional[str]) -> str:
    """
    Pergunta o modo no início da execução (input).
    Atalho para automação: --modo ou variável BCA_MODO pulam a pergunta.
    """
    atalho = (argumento or os.getenv("BCA_MODO") or "").strip().lower()
    if atalho in ("python", "modelo"):
        return atalho
    if atalho:
        raise ValueError(f"Modo inválido: {atalho!r}. Use 'python' ou 'modelo'.")

    print("\nModo de extração do BCA:")
    print("  [1] Python - determinístico, sem API (recomendado)")
    print("  [2] Modelo - Gemini em lotes (lento, usa quota)")
    while True:
        try:
            resp = input("Escolha 1 ou 2 [1]: ").strip().lower()
        except EOFError:  # execução sem entrada interativa
            log_aviso("Sem entrada interativa; usando modo python.")
            return "python"
        if resp in ("", "1", "python"):
            return "python"
        if resp in ("2", "modelo"):
            return "modelo"
        log_aviso("Opção inválida. Digite 1 ou 2.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Agente Engenheiro - extração do BCA")
    parser.add_argument(
        "--modo", choices=["python", "modelo"], default=None,
        help="Pula a pergunta inicial. python = sem LLM; modelo = Gemini "
             "(alternativa: variável de ambiente BCA_MODO)",
    )
    args = parser.parse_args()
    log_banner("02 MERCADO", "Extração do catálogo BCA")
    modo = escolher_modo(args.modo)
    log_info(
        f"Modo: {modo.upper()}"
        + (f" | Modelo: {MODELO_GEMINI}" if modo == "modelo" else "")
    )

    log_etapa(1, 2, "Validação do PDF BCA")
    info_pdf = validar_pdf(PDF_BCA)
    log_info(
        f"{info_pdf['arquivo']}: {info_pdf['paginas_pdf']} páginas "
        f"({info_pdf['paginas_com_texto']} com texto)"
    )

    log_etapa(2, 2, "Extração das tabelas do BCA")
    extracao, _ = extrair_bca(PDF_BCA, modo)

    com_alerta = [a for a in extracao.aeronaves if a.observacoes_extracao]
    for a in extracao.aeronaves:
        for obs in a.observacoes_extracao:
            if "marcador" not in obs and "'TO'" not in obs and "ausente" not in obs:
                log_aviso(f"{a.modelo}: {obs}")
    for aviso in extracao.avisos:
        log_aviso(aviso)

    log_resultado([
        ("Aeronaves extraídas", len(extracao.aeronaves)),
        ("Com observações de validação", len(com_alerta)),
        ("Catálogo", (PASTA_CACHE / (PDF_BCA.stem + "_aeronaves_extraidas.json")).resolve()),
    ])


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log_aviso("Execução interrompida pelo usuário.")
        sys.exit(130)
    except Exception as exc:
        logging.exception("Erro durante a execução do Agente Engenheiro")
        log_erro(str(exc))
        sys.exit(1)
