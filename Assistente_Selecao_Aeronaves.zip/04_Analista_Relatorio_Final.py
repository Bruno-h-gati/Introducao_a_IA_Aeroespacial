# -*- coding: utf-8 -*-
"""
AGENTE DE RELATÓRIO EXECUTIVO
Lê o JSON produzido pelo Agente Engenheiro e gera um PDF-resumo.
Não consulta Gemini, Ollama, BCA ou qualquer API externa.

Instalação:
    pip install reportlab

Execução:
    python agente_relatorio_pdf.py
    python agente_relatorio_pdf.py "caminho\\arquivo.json" ["caminho\\catalogo.json"]
"""

import json
import sys
from pathlib import Path
from datetime import datetime

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    KeepTogether, HRFlowable
)
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics


# =============================================================================
# PADRÃO DE SAÍDA NO TERMINAL (bloco idêntico nos quatro agentes)
# Sem símbolos fora do cp1252, para não falhar em consoles Windows.
# =============================================================================

_LARGURA_LOG = 70


def log_banner(agente: str, descricao: str = "") -> None:
    print("=" * _LARGURA_LOG)
    print(f"{agente} | {descricao}" if descricao else agente)
    print("=" * _LARGURA_LOG, flush=True)


def log_etapa(atual: int, total: int, texto: str) -> None:
    print(f"\n[{atual}/{total}] {texto}", flush=True)


def log_sub(texto: str) -> None:
    print(f"\n> {texto}", flush=True)


def log_info(texto: str) -> None:
    print(f"  {texto}", flush=True)


def log_api(texto: str) -> None:
    print(f"  [API] {texto}", flush=True)


def log_cache(texto: str) -> None:
    print(f"  [CACHE] {texto}", flush=True)


def log_ok(texto: str) -> None:
    print(f"  [OK] {texto}", flush=True)


def log_aviso(texto: str) -> None:
    print(f"  [AVISO] {texto}", flush=True)


def log_erro(texto: str) -> None:
    print(f"\n[ERRO] {texto}", flush=True)


def log_resultado(itens: list[tuple[str, object]]) -> None:
    largura = max((len(str(k)) for k, _ in itens), default=0)
    print("\n" + "-" * _LARGURA_LOG)
    print("RESULTADO")
    for chave, valor in itens:
        print(f"  {str(chave).ljust(largura)} : {valor}")
    print("-" * _LARGURA_LOG, flush=True)


# ============================================================
# CONFIGURAÇÃO
# ============================================================

PASTA_SAIDA = "relatorios_pdf"
COR_AZUL = colors.HexColor("#17365D")
COR_AZUL_CLARO = colors.HexColor("#DCE6F1")
COR_CINZA = colors.HexColor("#F2F4F7")
COR_TEXTO = colors.HexColor("#202833")
COR_VERDE = colors.HexColor("#E2F0D9")
COR_AMARELO = colors.HexColor("#FFF2CC")
COR_VERMELHO = colors.HexColor("#FCE4D6")


def formatar_numero(valor, casas=0):
    if valor is None:
        return "Não informado"
    return f"{valor:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def formatar_usd(valor):
    if valor is None:
        return "Não informado"
    return "US$ " + formatar_numero(float(valor), 0)


def texto(valor, padrao="Não informado"):
    if valor is None or valor == "":
        return padrao
    if isinstance(valor, list):
        return ", ".join(str(x) for x in valor) if valor else padrao
    return str(valor)


def escapar(valor):
    """Escapa caracteres especiais para uso seguro em Paragraph."""
    s = texto(valor)
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;"))


def criar_estilos():
    estilos = getSampleStyleSheet()
    estilos.add(ParagraphStyle(
        name="TituloRelatorio", parent=estilos["Title"],
        fontName="Helvetica-Bold", fontSize=19, leading=23,
        textColor=COR_AZUL, alignment=TA_LEFT, spaceAfter=5
    ))
    estilos.add(ParagraphStyle(
        name="Subtitulo", parent=estilos["Normal"],
        fontSize=9, leading=13, textColor=colors.HexColor("#5B6573"),
        spaceAfter=12
    ))
    estilos.add(ParagraphStyle(
        name="Secao", parent=estilos["Heading2"],
        fontName="Helvetica-Bold", fontSize=12, leading=15,
        textColor=COR_AZUL, spaceBefore=11, spaceAfter=6
    ))
    estilos.add(ParagraphStyle(
        name="Corpo", parent=estilos["BodyText"],
        fontSize=9, leading=13, textColor=COR_TEXTO, spaceAfter=4
    ))
    estilos.add(ParagraphStyle(
        name="Pequeno", parent=estilos["BodyText"],
        fontSize=7.5, leading=10, textColor=colors.HexColor("#596273")
    ))
    estilos.add(ParagraphStyle(
        name="Celula", parent=estilos["BodyText"],
        fontSize=8, leading=10, textColor=COR_TEXTO
    ))
    estilos.add(ParagraphStyle(
        name="CelulaCabecalho", parent=estilos["BodyText"],
        fontName="Helvetica-Bold", fontSize=8, leading=10,
        textColor=colors.white
    ))
    estilos.add(ParagraphStyle(
        name="Destaque", parent=estilos["BodyText"],
        fontName="Helvetica-Bold", fontSize=13, leading=17,
        textColor=COR_AZUL
    ))
    return estilos


def adicionar_lista(story, itens, estilo):
    if not itens:
        story.append(Paragraph("Nenhum item registrado.", estilo))
        return
    for item in itens:
        story.append(Paragraph("• " + escapar(item), estilo))


def _norm(valor):
    """Minúsculas e espaços normalizados, para comparação."""
    return " ".join(str(valor or "").lower().split())


def localizar_aeronave(nome_busca, registros):
    """
    Busca uma aeronave em uma lista de registros (dicts com 'fabricante' e 'modelo').
    1) coleta todos os fabricantes presentes nos registros;
    2) se o nome começa com um deles, remove essa parte;
    3) procura o modelo restante (priorizando o mesmo fabricante).
    Ex.: 'Embraer Praetor 600 EMB-550' -> fabricante 'Embraer' + modelo 'Praetor 600 EMB-550'.
    """
    nome = _norm(nome_busca)
    if not nome or not registros:
        return None

    fabricantes = sorted(
        {_norm(a.get("fabricante")) for a in registros if a.get("fabricante")},
        key=len, reverse=True
    )

    fabricante_achado = None
    modelo_busca = nome
    for fab in fabricantes:
        if nome == fab or nome.startswith(fab + " "):
            fabricante_achado = fab
            modelo_busca = nome[len(fab):].strip()
            break
    if not modelo_busca:
        return None

    candidatos = [
        a for a in registros
        if fabricante_achado is None or _norm(a.get("fabricante")) == fabricante_achado
    ] or registros

    for a in candidatos:                      # igualdade exata
        if _norm(a.get("modelo")) == modelo_busca:
            return a
    for a in candidatos:                      # um contém o outro
        m = _norm(a.get("modelo"))
        if m and (modelo_busca in m or m in modelo_busca):
            return a
    return None


def obter_candidato_selecionado(dados):
    nome = (dados.get("analise_gemini") or {}).get("melhor_candidato_preliminar")
    candidato = localizar_aeronave(nome, dados.get("resultados_triagem", []))
    if nome and candidato is None:
        log_aviso(f"Candidato '{nome}' não localizado em resultados_triagem.")
    return candidato


def carregar_catalogo(caminho_json, dados, caminho_catalogo=None):
    """
    Carrega o catálogo BCA extraído (ex.: BCA_2026_aeronaves_extraidas.json),
    cujo nome vem no próprio JSON do Engenheiro. Procura ao lado do JSON,
    na pasta acima e, por último, em toda a raiz do projeto.
    Retorna lista de registros ou [] se não encontrar.
    """
    nome = (dados.get("catalogo_extraido_bca_arquivo")
            or (dados.get("fonte_bca") or {}).get("cache"))
    caminhos = []
    if caminho_catalogo:
        caminhos.append(Path(caminho_catalogo).expanduser())
    if nome:
        pasta = Path(caminho_json).resolve().parent
        caminhos += [pasta / nome, pasta.parent / nome]
        caminhos += list(pasta.parent.rglob(nome))

    for c in caminhos:
        if not c.is_file():
            continue
        try:
            with open(c, "r", encoding="utf-8") as f:
                bruto = json.load(f)
        except Exception as erro:
            log_aviso(f"Não foi possível ler o catálogo {c.name}: {erro}")
            continue
        if isinstance(bruto, dict):  # aceita {"aeronaves": [...]} ou similar
            bruto = next((v for v in bruto.values()
                          if isinstance(v, list) and v and isinstance(v[0], dict)), [])
        registros = [r for r in bruto if isinstance(r, dict)]
        if registros:
            log_info(f"Catálogo BCA: {c.name} ({len(registros)} aeronaves)")
            return registros

    log_aviso(
        "Catálogo BCA extraído não encontrado; "
        "alternativas ficarão sem preço/alcance/passageiros."
    )
    return []


# campo usado no relatório -> nomes possíveis no registro (resultados_triagem / catálogo BCA)
CAMPOS_ALTERNATIVA = {
    "preco_bca_usd": ("preco_bca_usd", "preco_usd"),
    "nbaa_ifr_range_nm_bca": ("nbaa_ifr_range_nm_bca", "nbaa_ifr_range_nm"),
    "assentos_passageiros_max_bca": ("assentos_passageiros_max_bca", "assentos_passageiros_max"),
}


def _primeiro_valor(registro, nomes):
    for n in nomes:
        if registro.get(n) is not None:
            return registro[n]
    return None


def completar_alternativa(item, catalogo):
    """Preenche os campos ausentes de uma alternativa com os dados do catálogo."""
    nome = f"{item.get('fabricante', '')} {item.get('modelo', '')}".strip()
    registro = localizar_aeronave(nome, catalogo)
    if not registro:
        log_aviso(f"'{nome}' não localizado no catálogo.")
        return item
    completo = dict(item)
    for campo, nomes in CAMPOS_ALTERNATIVA.items():
        if completo.get(campo) is None:
            completo[campo] = _primeiro_valor(registro, nomes)
    return completo


def obter_comparacao(aeronave, chave):
    if not aeronave:
        return {}
    return (aeronave.get("comparacoes") or {}).get(chave) or {}


def montar_pdf(caminho_json, caminho_pdf, caminho_catalogo=None):
    log_etapa(1, 2, "Leitura do JSON e do catálogo BCA")
    with open(caminho_json, "r", encoding="utf-8") as arquivo:
        dados = json.load(arquivo)

    perfil = dados.get("perfil_missao_recebido", {})
    analise = dados.get("analise_gemini", {})
    candidato = obter_candidato_selecionado(dados)
    catalogo = carregar_catalogo(caminho_json, dados, caminho_catalogo)
    estilos = criar_estilos()
    log_etapa(2, 2, "Geração do PDF")

    cliente = dados.get("cliente_numero", "N/I")
    data_raw = dados.get("data_processamento", "")
    try:
        data_formatada = datetime.fromisoformat(data_raw).strftime("%d/%m/%Y às %H:%M")
    except Exception:
        data_formatada = texto(data_raw)

    doc = SimpleDocTemplate(
        str(caminho_pdf), pagesize=A4,
        rightMargin=18*mm, leftMargin=18*mm,
        topMargin=16*mm, bottomMargin=16*mm,
        title=f"Relatório Executivo - Cliente {cliente}",
        author="Agente de Relatório PDF"
    )

    story = []

    # --------------------------------------------------------
    # CABEÇALHO
    # --------------------------------------------------------
    story.append(Paragraph("RELATÓRIO EXECUTIVO", estilos["TituloRelatorio"]))
    story.append(Paragraph(
        f"Triagem técnica de aeronave executiva | Cliente {escapar(cliente)}"
        f" | Processado em {escapar(data_formatada)}",
        estilos["Subtitulo"]
    ))
    story.append(HRFlowable(width="100%", thickness=1.2, color=COR_AZUL))
    story.append(Spacer(1, 8))

    # --------------------------------------------------------
    # RESUMO DA MISSÃO
    # --------------------------------------------------------
    story.append(Paragraph("1. Requisitos da missão", estilos["Secao"]))

    linhas_missao = [
        [Paragraph("<b>Origem</b>", estilos["Celula"]),
         Paragraph(escapar(perfil.get("origem")), estilos["Celula"]),
         Paragraph("<b>Destino</b>", estilos["Celula"]),
         Paragraph(escapar(perfil.get("destino")), estilos["Celula"])],
        [Paragraph("<b>Passageiros</b>", estilos["Celula"]),
         Paragraph(escapar(perfil.get("numero_passageiros")), estilos["Celula"]),
         Paragraph("<b>Distância</b>", estilos["Celula"]),
         Paragraph(texto(perfil.get("distancia_milhas_nauticas")) + " nm", estilos["Celula"])],
        [Paragraph("<b>Pista disponível</b>", estilos["Celula"]),
         Paragraph(texto(perfil.get("comprimento_pista_pes")) + " ft", estilos["Celula"]),
         Paragraph("<b>Orçamento</b>", estilos["Celula"]),
         Paragraph(escapar(perfil.get("orcamento_aquisicao")), estilos["Celula"])],
        [Paragraph("<b>Voo sem escala</b>", estilos["Celula"]),
         Paragraph("Sim" if perfil.get("voo_sem_escala") else "Não/não informado", estilos["Celula"]),
         Paragraph("<b>Bagagem</b>", estilos["Celula"]),
         Paragraph(escapar(perfil.get("bagagem")), estilos["Celula"])],
    ]
    tabela = Table(linhas_missao, colWidths=[29*mm, 55*mm, 29*mm, 61*mm])
    tabela.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), COR_AZUL_CLARO),
        ("BACKGROUND", (2, 0), (2, -1), COR_AZUL_CLARO),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C8D0DA")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(tabela)

    necessidades = perfil.get("necessidades_operacionais", [])
    if necessidades:
        story.append(Spacer(1, 5))
        story.append(Paragraph(
            "<b>Necessidades operacionais:</b> " + escapar(necessidades),
            estilos["Corpo"]
        ))

    # --------------------------------------------------------
    # RECOMENDAÇÃO
    # --------------------------------------------------------
    story.append(Paragraph("2. Aeronave indicada pela triagem", estilos["Secao"]))

    nome_recomendado = analise.get("melhor_candidato_preliminar")
    if candidato:
        nome_recomendado = candidato.get("modelo", nome_recomendado)
        fabricante = candidato.get("fabricante", "")
        preco = candidato.get("preco_bca_usd")
        assentos = candidato.get("assentos_passageiros_max_bca")
        alcance = candidato.get("nbaa_ifr_range_nm_bca")
        tofl = candidato.get("tofl_sl_isa_ft_bca")
        pagina = candidato.get("pagina_bca")
    else:
        fabricante = preco = assentos = alcance = tofl = pagina = None

    bloco_destaque = [
        Paragraph(escapar(nome_recomendado), estilos["Destaque"]),
        Paragraph(escapar(fabricante), estilos["Pequeno"])
    ]
    destaque = Table([[bloco_destaque]], colWidths=[174*mm])
    destaque.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), COR_AZUL_CLARO),
        ("BOX", (0, 0), (-1, -1), 0.8, COR_AZUL),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(destaque)
    story.append(Spacer(1, 7))

    dados_aeronave = [
        ["Preço BCA", "Passageiros máx.", "Alcance NBAA IFR", "TOFL SL ISA"],
        [formatar_usd(preco), texto(assentos), texto(alcance) + " nm",
         texto(tofl) + " ft"]
    ]
    tabela_aeronave = Table(dados_aeronave, colWidths=[43.5*mm]*4)
    tabela_aeronave.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), COR_AZUL),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("BACKGROUND", (0, 1), (-1, 1), COR_CINZA),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.white),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    story.append(tabela_aeronave)
    if pagina:
        story.append(Paragraph(
            f"Fonte: BCA 2026, página {escapar(pagina)}.",
            estilos["Pequeno"]
        ))

    story.append(Spacer(1, 5))
    story.append(Paragraph("<b>Justificativa técnica:</b>", estilos["Corpo"]))
    story.append(Paragraph(escapar(analise.get("justificativa")), estilos["Corpo"]))

    # --------------------------------------------------------
    # CRITÉRIOS DA AERONAVE
    # --------------------------------------------------------
    story.append(Paragraph("3. Atendimento aos critérios", estilos["Secao"]))

    criterios = [
        ("Orçamento", "orcamento"),
        ("Capacidade de passageiros", "passageiros"),
        ("Alcance NBAA IFR", "alcance_nbaa_ifr"),
        ("Comprimento de pista", "pista_sl_isa"),
    ]

    linhas = [[
        Paragraph("Critério", estilos["CelulaCabecalho"]),
        Paragraph("Resultado da triagem", estilos["CelulaCabecalho"]),
        Paragraph("Detalhe registrado", estilos["CelulaCabecalho"])
    ]]

    for rotulo, chave in criterios:
        comp = obter_comparacao(candidato, chave)
        status = comp.get("status", "Não informado")
        detalhe = comp.get("detalhe", "Sem detalhe registrado.")
        linhas.append([
            Paragraph(escapar(rotulo), estilos["Celula"]),
            Paragraph(escapar(status), estilos["Celula"]),
            Paragraph(escapar(detalhe), estilos["Celula"])
        ])

    tabela_criterios = Table(linhas, colWidths=[42*mm, 42*mm, 92*mm], repeatRows=1)
    tabela_criterios.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), COR_AZUL),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C8D0DA")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(tabela_criterios)

    # --------------------------------------------------------
    # RISCOS E CONFIRMAÇÕES
    # --------------------------------------------------------
    story.append(Paragraph("4. Riscos técnicos e pontos a confirmar", estilos["Secao"]))
    story.append(Paragraph("<b>Riscos técnicos:</b>", estilos["Corpo"]))
    adicionar_lista(story, analise.get("riscos_tecnicos", []), estilos["Corpo"])

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Dados que precisam ser confirmados:</b>", estilos["Corpo"]))
    adicionar_lista(story, analise.get("dados_a_confirmar", []), estilos["Corpo"])

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Ressalvas:</b>", estilos["Corpo"]))
    adicionar_lista(story, analise.get("ressalvas", []), estilos["Corpo"])

    # --------------------------------------------------------
    # ALTERNATIVAS
    # --------------------------------------------------------
    alternativas = [
        x for x in dados.get("resultados_triagem", [])
        if x.get("classificacao_preliminar") == "COM_RESTRICAO_NA_TRIAGEM"
    ]
    alternativas = [completar_alternativa(x, catalogo) for x in alternativas[:5]]

    if alternativas:
        story.append(Paragraph("5. Alternativas avaliadas", estilos["Secao"]))
        linhas_alt = [[
            Paragraph("Aeronave", estilos["CelulaCabecalho"]),
            Paragraph("Preço BCA", estilos["CelulaCabecalho"]),
            Paragraph("Alcance (nm)", estilos["CelulaCabecalho"]),
            Paragraph("Passageiros", estilos["CelulaCabecalho"]),
            Paragraph("Restrição identificada", estilos["CelulaCabecalho"])
        ]]
        for item in alternativas:
            restricoes = item.get("restricoes_identificadas") or []
            linhas_alt.append([
                Paragraph(escapar(item.get("modelo")), estilos["Celula"]),
                Paragraph(formatar_usd(item.get("preco_bca_usd")), estilos["Celula"]),
                Paragraph(texto(item.get("nbaa_ifr_range_nm_bca")), estilos["Celula"]),
                Paragraph(texto(item.get("assentos_passageiros_max_bca")), estilos["Celula"]),
                Paragraph(escapar(", ".join(restricoes) if restricoes else "Ver detalhes"), estilos["Celula"])
            ])
        tabela_alt = Table(
            linhas_alt,
            colWidths=[55*mm, 30*mm, 25*mm, 25*mm, 41*mm],
            repeatRows=1
        )
        tabela_alt.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), COR_AZUL),
            ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C8D0DA")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(tabela_alt)
        story.append(Paragraph(
            "A tabela apresenta até cinco alternativas classificadas com restrição. "
            "A ausência de uma aeronave nesta lista não representa aprovação operacional.",
            estilos["Pequeno"]
        ))

    # --------------------------------------------------------
    # METODOLOGIA E LIMITAÇÕES
    # --------------------------------------------------------
    story.append(Paragraph("6. Metodologia e limitações", estilos["Secao"]))
    story.append(Paragraph(
        "Este documento resume os resultados já registrados no JSON do Agente "
        "Engenheiro. Não executa nova extração, cálculo, consulta a catálogo ou "
        "avaliação por inteligência artificial.",
        estilos["Corpo"]
    ))
    adicionar_lista(story, dados.get("metodologia_e_limitacoes", []), estilos["Pequeno"])

    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#AAB4C0")))
    story.append(Paragraph(
        "Documento de triagem preliminar. Não substitui análise de performance "
        "da aeronave, AFM/POH, consulta ao fabricante, planejamento operacional "
        "ou despacho de voo.",
        estilos["Pequeno"]
    ))

    def rodape(canvas, documento):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#687385"))
        canvas.drawString(18*mm, 9*mm, "Relatório gerado automaticamente a partir do JSON do Agente Engenheiro")
        canvas.drawRightString(A4[0] - 18*mm, 9*mm, f"Página {documento.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=rodape, onLaterPages=rodape)
    return caminho_pdf


def main():
    log_banner("04 RELATÓRIO", "Resumo executivo em PDF")

    if len(sys.argv) >= 2:
        caminho_json = Path(sys.argv[1]).expanduser()
    else:
        entrada = input("Caminho do arquivo JSON: ").strip().strip('"')
        caminho_json = Path(entrada).expanduser()

    if not caminho_json.is_file():
        log_erro(f"Arquivo não encontrado: {caminho_json}")
        sys.exit(1)

    # A raiz do projeto é a pasta acima do JSON; o PDF vai para 04_relatorio.
    pasta_projeto = caminho_json.resolve().parent.parent
    pasta_saida = pasta_projeto / "04_relatorio"
    pasta_saida.mkdir(parents=True, exist_ok=True)

    caminho_pdf = pasta_saida / (caminho_json.stem + "_resumo_executivo.pdf")

    try:
        caminho_catalogo = sys.argv[2] if len(sys.argv) >= 3 else None
        resultado = montar_pdf(caminho_json, caminho_pdf, caminho_catalogo)

        log_resultado([
            ("Cliente", caminho_json.stem),
            ("PDF", resultado.resolve()),
        ])

    except json.JSONDecodeError as erro:
        log_erro(f"JSON inválido: {erro}")
        sys.exit(1)

    except Exception as erro:
        log_erro(f"Geração do PDF - {type(erro).__name__}: {erro}")
        raise


if __name__ == "__main__":
    main()
